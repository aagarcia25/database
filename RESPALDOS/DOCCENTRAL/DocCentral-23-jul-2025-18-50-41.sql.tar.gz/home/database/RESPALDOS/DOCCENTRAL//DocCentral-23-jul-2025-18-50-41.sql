-- MariaDB dump 10.19  Distrib 10.8.6-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: DocCentral
-- ------------------------------------------------------
-- Server version	10.8.6-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ActivacionCodigos`
--

DROP TABLE IF EXISTS `ActivacionCodigos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ActivacionCodigos` (
  `Id` char(36) NOT NULL DEFAULT uuid(),
  `IdPathDoc` char(36) NOT NULL,
  `Phrase` varchar(255) DEFAULT NULL,
  `Estatus` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ActivacionCodigos`
--

LOCK TABLES `ActivacionCodigos` WRITE;
/*!40000 ALTER TABLE `ActivacionCodigos` DISABLE KEYS */;
INSERT INTO `ActivacionCodigos` VALUES
('019a4cc4-983d-11ed-a912-705a0f328da6','74e61289-92c6-11ed-a912-705a0f328da6','XIXBIATW',1,'2023-01-19 21:04:16','2023-01-19 21:04:53'),
('04d3ffe9-98f3-11ed-b58e-2c4138b7dab1','1f79ef71-91e3-11ed-a912-705a0f328da6','Jj1Po8uS',1,'2023-01-20 17:45:59','2023-01-20 17:47:16'),
('05a9d8f5-9913-11ed-b58e-2c4138b7dab1','74e61289-92c6-11ed-a912-705a0f328da6','VSpB4csw',0,'2023-01-20 21:35:05','2023-01-20 21:35:05'),
('1d6ddde2-98f3-11ed-b58e-2c4138b7dab1','1f79ef71-91e3-11ed-a912-705a0f328da6','w2e9830O',0,'2023-01-20 17:46:40','2023-01-20 17:46:40'),
('1ff3d68f-a0e8-11ed-802e-2c4138b7dab1','d5a0d0b9-a0e7-11ed-802e-2c4138b7dab1','w7TDcqLm',1,'2023-01-30 21:49:31','2023-01-30 21:50:01'),
('2157ec31-a0d6-11ed-802e-2c4138b7dab1','c0aea734-a0d4-11ed-802e-2c4138b7dab1','S81aI1I6',0,'2023-01-30 19:40:42','2023-01-30 19:40:42'),
('21d0239a-9daf-11ed-b58e-2c4138b7dab1','0077d09b-9daf-11ed-b58e-2c4138b7dab1','swkDhnN9',1,'2023-01-26 18:22:44','2023-01-26 18:23:14'),
('3f208768-9c3e-11ed-b58e-2c4138b7dab1','3ed0f82d-9c3d-11ed-b58e-2c4138b7dab1','WxNzr6jB',0,'2023-01-24 22:22:07','2023-01-24 22:22:07'),
('447b3e66-a0e4-11ed-802e-2c4138b7dab1','31c8f48b-a0e4-11ed-802e-2c4138b7dab1','PyvJuFDW',1,'2023-01-30 21:21:54','2023-01-30 21:22:11'),
('4627e56f-983c-11ed-a912-705a0f328da6','74e61289-92c6-11ed-a912-705a0f328da6','PFDTWqFd',0,'2023-01-19 20:59:01','2023-01-19 20:59:01'),
('485b5ff7-977c-11ed-a912-705a0f328da6','5139f008-9778-11ed-a8fc-0242ac120002','XeWIHfNB',0,'2023-01-18 22:04:41','2023-01-18 22:04:41'),
('4904123b-9db7-11ed-b58e-2c4138b7dab1','0077d09b-9daf-11ed-b58e-2c4138b7dab1','RywIcbMc',0,'2023-01-26 19:21:06','2023-01-26 19:21:06'),
('4943c557-98ec-11ed-b58e-2c4138b7dab1','74e61289-92c6-11ed-a912-705a0f328da6','YdehWtVk',0,'2023-01-20 16:57:47','2023-01-20 16:57:47'),
('4d314e4d-9818-11ed-a912-705a0f328da6','74e61289-92c6-11ed-a912-705a0f328da6','cV6pBYG8',1,'2023-01-19 16:41:31','2023-01-19 20:46:10'),
('511f7644-9912-11ed-b58e-2c4138b7dab1','78d2bcec-96af-11ed-a912-705a0f328da6','SfG7cBLI',0,'2023-01-20 21:30:02','2023-01-20 21:30:02'),
('572ab839-98fa-11ed-b58e-2c4138b7dab1','092dd5d7-92b2-11ed-a912-705a0f328da6','eFGcaxIY',1,'2023-01-20 18:38:24','2023-01-20 18:39:41'),
('5d6f7594-a0e7-11ed-802e-2c4138b7dab1','10787d0a-a0e7-11ed-802e-2c4138b7dab1','ExQF6FSw',1,'2023-01-30 21:44:05','2023-01-30 21:44:31'),
('62f089bc-9db9-11ed-b58e-2c4138b7dab1','778d0f9a-9db7-11ed-b58e-2c4138b7dab1','oRRqoI33',1,'2023-01-26 19:36:08','2023-01-26 19:36:44'),
('65cb23d8-9780-11ed-a912-705a0f328da6','5139f332-9778-11ed-a8fc-0242ac120002','nCJuc1zu',0,'2023-01-18 22:34:08','2023-01-18 22:34:08'),
('6869dc68-a0e4-11ed-802e-2c4138b7dab1','31c8f48b-a0e4-11ed-802e-2c4138b7dab1','4Upu1KVt',0,'2023-01-30 21:22:55','2023-01-30 21:22:55'),
('6acd4e6a-9b68-11ed-b58e-2c4138b7dab1','46f9922a-9b68-11ed-b58e-2c4138b7dab1','9u7z67i2',1,'2023-01-23 20:51:27','2023-01-23 20:52:11'),
('6fad78b0-9d02-11ed-b58e-2c4138b7dab1','63adee79-9d02-11ed-b58e-2c4138b7dab1','C5PynrLd',1,'2023-01-25 21:46:31','2023-01-25 21:47:00'),
('73e7408b-a0ee-11ed-802e-2c4138b7dab1','4f15f48c-a0ee-11ed-802e-2c4138b7dab1','yTPhMrCJ',1,'2023-01-30 22:34:49','2023-01-30 22:35:16'),
('7566c996-9b46-11ed-b58e-2c4138b7dab1','0af5414c-9b46-11ed-b58e-2c4138b7dab1','n1QmBP7H',0,'2023-01-23 16:48:22','2023-01-23 16:48:22'),
('76651a7a-a0e3-11ed-802e-2c4138b7dab1','ceb27c2a-a0e0-11ed-802e-2c4138b7dab1','Iyq79VcP',0,'2023-01-30 21:16:09','2023-01-30 21:16:09'),
('7c3f829e-98f0-11ed-b58e-2c4138b7dab1','5e1ba20b-91e4-11ed-a912-705a0f328da6','rzme5xQZ',0,'2023-01-20 17:27:51','2023-01-20 17:27:51'),
('7f0f0111-98f1-11ed-b58e-2c4138b7dab1','1af820ef-91dd-11ed-a912-705a0f328da6','gu7YHmyI',0,'2023-01-20 17:35:05','2023-01-20 17:35:05'),
('90e9a65d-9828-11ed-a912-705a0f328da6','74e61289-92c6-11ed-a912-705a0f328da6','THwRtmKd',0,'2023-01-19 18:37:57','2023-01-19 18:37:57'),
('9dc7697e-a0e1-11ed-802e-2c4138b7dab1','ceb27c2a-a0e0-11ed-802e-2c4138b7dab1','6SKpu3S8',0,'2023-01-30 21:02:56','2023-01-30 21:02:56'),
('a13aa3d7-a0e1-11ed-802e-2c4138b7dab1','7053afeb-a0df-11ed-802e-2c4138b7dab1','QQYJdiOE',0,'2023-01-30 21:03:01','2023-01-30 21:03:01'),
('a22da2ed-a283-11ed-b561-2c4138b7dab1','e9f79dad-a282-11ed-b561-2c4138b7dab1','Dy9UrRML',1,'2023-02-01 22:55:15','2023-02-01 22:55:34'),
('a92be6f3-983a-11ed-a912-705a0f328da6','74e61289-92c6-11ed-a912-705a0f328da6','r3c85s6d',0,'2023-01-19 20:47:28','2023-01-19 20:47:28'),
('ad949543-98f7-11ed-b58e-2c4138b7dab1','78d2bcec-96af-11ed-a912-705a0f328da6','dM3X3dnM',1,'2023-01-20 18:19:20','2023-01-20 18:19:56'),
('b02f3675-98eb-11ed-b58e-2c4138b7dab1','74e61289-92c6-11ed-a912-705a0f328da6','D7I7RSTj',0,'2023-01-20 16:53:31','2023-01-20 16:53:31'),
('b6be0804-98fa-11ed-b58e-2c4138b7dab1','092dd5d7-92b2-11ed-a912-705a0f328da6','UXQ0PL5r',0,'2023-01-20 18:41:04','2023-01-20 18:41:04'),
('b6ca32a5-98f8-11ed-b58e-2c4138b7dab1','78d2bcec-96af-11ed-a912-705a0f328da6','zijsytkU',0,'2023-01-20 18:26:45','2023-01-20 18:26:45'),
('b78aefbd-a0f9-11ed-802e-2c4138b7dab1','7eddb76e-a0f7-11ed-802e-2c4138b7dab1','onaATHhb',1,'2023-01-30 23:55:27','2023-01-30 23:55:54'),
('b9ab5249-98f0-11ed-b58e-2c4138b7dab1','131afd08-91d1-11ed-a912-705a0f328da6','CC0ZNAbp',0,'2023-01-20 17:29:34','2023-01-20 17:29:34'),
('bfbada0d-98f6-11ed-b58e-2c4138b7dab1','78d2bcec-96af-11ed-a912-705a0f328da6','EGkMdWFX',1,'2023-01-20 18:12:41','2023-01-20 18:14:19'),
('c52d1af0-98fa-11ed-b58e-2c4138b7dab1','092dd5d7-92b2-11ed-a912-705a0f328da6','odpzDF54',0,'2023-01-20 18:41:28','2023-01-20 18:41:28'),
('c9992356-9780-11ed-a912-705a0f328da6','5139f56c-9778-11ed-a8fc-0242ac120002','0nORphAB',0,'2023-01-18 22:36:56','2023-01-18 22:36:56'),
('cda7c312-9912-11ed-b58e-2c4138b7dab1','5b7c3dfb-95ee-11ed-a912-705a0f328da6','PdTzkE4v',0,'2023-01-20 21:33:31','2023-01-20 21:33:31'),
('d47aa156-a24f-11ed-b561-2c4138b7dab1','7eddb76e-a0f7-11ed-802e-2c4138b7dab1','uoC0c2po',0,'2023-02-01 16:44:25','2023-02-01 16:44:25'),
('d4bdf29c-9b48-11ed-b58e-2c4138b7dab1','0af5414c-9b46-11ed-b58e-2c4138b7dab1','LXqmzL49',0,'2023-01-23 17:05:20','2023-01-23 17:05:20'),
('d664165c-98f1-11ed-b58e-2c4138b7dab1','1af820ef-91dd-11ed-a912-705a0f328da6','N6sQwVbG',0,'2023-01-20 17:37:32','2023-01-20 17:37:32'),
('e1edc1d1-98f6-11ed-b58e-2c4138b7dab1','78d2bcec-96af-11ed-a912-705a0f328da6','LFyqWsIi',0,'2023-01-20 18:13:39','2023-01-20 18:13:39'),
('e2f1b88b-9912-11ed-b58e-2c4138b7dab1','5b7c3dfb-95ee-11ed-a912-705a0f328da6','59WiTvXJ',0,'2023-01-20 21:34:06','2023-01-20 21:34:06'),
('eb89ea53-983c-11ed-a912-705a0f328da6','74e61289-92c6-11ed-a912-705a0f328da6','A6wir00H',0,'2023-01-19 21:03:39','2023-01-19 21:03:39'),
('ec362fb6-9779-11ed-a912-705a0f328da6','5139f008-9778-11ed-a8fc-0242ac120002','5ViASaoP',0,'2023-01-18 21:47:47','2023-01-18 21:47:47'),
('f6f1166c-b2e2-11ed-9bd4-2c4138b7dab1','d0da6af0-b2e1-11ed-9bd4-2c4138b7dab1','nyWC08uB',0,'2023-02-22 18:58:59','2023-02-22 18:58:59');
/*!40000 ALTER TABLE `ActivacionCodigos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ConCopia`
--

DROP TABLE IF EXISTS `ConCopia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ConCopia` (
  `Id` char(36) NOT NULL DEFAULT uuid(),
  `Nombre` varchar(100) NOT NULL,
  `Puesto` varchar(50) NOT NULL,
  `Correo` varchar(100) NOT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ConCopia`
--

LOCK TABLES `ConCopia` WRITE;
/*!40000 ALTER TABLE `ConCopia` DISABLE KEYS */;
INSERT INTO `ConCopia` VALUES
('3e85906d-a0eb-11ed-802e-2c4138b7dab1','jose','dba','joseaguedosernameza@gmail.com'),
('3eadabf3-a0eb-11ed-802e-2c4138b7dab1','jose','dba','joseaguedosernameza@gmail.com'),
('3ece46a1-a0eb-11ed-802e-2c4138b7dab1','jose','dba','joseaguedosernameza@gmail.com'),
('3ee85c9e-a0eb-11ed-802e-2c4138b7dab1','jose','dba','joseaguedosernameza@gmail.com'),
('3f053f52-a0eb-11ed-802e-2c4138b7dab1','jose','dba','joseaguedosernameza@gmail.com'),
('3f1f49bc-a0eb-11ed-802e-2c4138b7dab1','jose','dba','joseaguedosernameza@gmail.com'),
('3f3a6aae-a0eb-11ed-802e-2c4138b7dab1','jose','dba','joseaguedosernameza@gmail.com'),
('3f595f91-a0eb-11ed-802e-2c4138b7dab1','jose','dba','joseaguedosernameza@gmail.com'),
('3f7663ee-a0eb-11ed-802e-2c4138b7dab1','jose','dba','joseaguedosernameza@gmail.com'),
('3f92342d-a0eb-11ed-802e-2c4138b7dab1','jose','dba','joseaguedosernameza@gmail.com'),
('3faf288a-a0eb-11ed-802e-2c4138b7dab1','jose','dba','joseaguedosernameza@gmail.com'),
('40069a51-a0eb-11ed-802e-2c4138b7dab1','jose','dba','joseaguedosernameza@gmail.com'),
('759863a3-a0ea-11ed-802e-2c4138b7dab1','jose','dba','joseaguedosernameza@gmail.com'),
('76c290f8-a0ea-11ed-802e-2c4138b7dab1','jose','dba','joseaguedosernameza@gmail.com'),
('773b9e55-a0ea-11ed-802e-2c4138b7dab1','jose','dba','joseaguedosernameza@gmail.com'),
('7b6e2b78-a0ea-11ed-802e-2c4138b7dab1','jose','dba','joseaguedosernameza@gmail.com'),
('7b935525-a0ea-11ed-802e-2c4138b7dab1','jose','dba','joseaguedosernameza@gmail.com'),
('7baee570-a0ea-11ed-802e-2c4138b7dab1','jose','dba','joseaguedosernameza@gmail.com'),
('7bca36ae-a0ea-11ed-802e-2c4138b7dab1','jose','dba','joseaguedosernameza@gmail.com'),
('7be912f9-a0ea-11ed-802e-2c4138b7dab1','jose','dba','joseaguedosernameza@gmail.com'),
('7c062036-a0ea-11ed-802e-2c4138b7dab1','jose','dba','joseaguedosernameza@gmail.com'),
('7c234db5-a0ea-11ed-802e-2c4138b7dab1','jose','dba','joseaguedosernameza@gmail.com'),
('7c42445d-a0ea-11ed-802e-2c4138b7dab1','jose','dba','joseaguedosernameza@gmail.com'),
('7c7e48c3-a0ea-11ed-802e-2c4138b7dab1','jose','dba','joseaguedosernameza@gmail.com'),
('7c9bafa6-a0ea-11ed-802e-2c4138b7dab1','jose','dba','joseaguedosernameza@gmail.com'),
('7cc1b8ae-a0ea-11ed-802e-2c4138b7dab1','jose','dba','joseaguedosernameza@gmail.com'),
('7cdc96a4-a0ea-11ed-802e-2c4138b7dab1','jose','dba','joseaguedosernameza@gmail.com'),
('7cff0104-a0ea-11ed-802e-2c4138b7dab1','jose','dba','joseaguedosernameza@gmail.com'),
('7d1ac22c-a0ea-11ed-802e-2c4138b7dab1','jose','dba','joseaguedosernameza@gmail.com'),
('7d3b3ce9-a0ea-11ed-802e-2c4138b7dab1','jose','dba','joseaguedosernameza@gmail.com'),
('7d5bde72-a0ea-11ed-802e-2c4138b7dab1','jose','dba','joseaguedosernameza@gmail.com');
/*!40000 ALTER TABLE `ConCopia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Configuraciones`
--

DROP TABLE IF EXISTS `Configuraciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Configuraciones` (
  `Id` char(36) NOT NULL,
  `IdApp` char(36) DEFAULT NULL,
  `RequiereTokenDescarga` tinyint(4) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Configuraciones`
--

LOCK TABLES `Configuraciones` WRITE;
/*!40000 ALTER TABLE `Configuraciones` DISABLE KEYS */;
INSERT INTO `Configuraciones` VALUES
('05601143-64c1-45ad-bd4b-31e0f199b5f4','47c46fe6-b148-11ed-afa1-0242ac120002',0,'2023-03-11 00:23:40','2023-03-11 00:23:40',0),
('2db9eb33-f5d6-4753-b0b7-1c2b72f5aebc','47c46fe6-b148-11ed-afa1-0242ac120002',0,'2023-02-20 19:13:08','2023-02-21 15:24:36',0),
('6f1f0104-76c2-4fe6-86dd-831244602f12','973ecf89-38ff-11ed-aed0-040300000000',0,'2023-02-23 19:00:33','2023-02-23 19:00:33',0),
('82bccaa3-5b93-4f5d-87e5-746b7ad777d3','573ecf89-38ff-11ed-aed0-040300000000',0,'2023-02-23 16:58:06','2023-02-23 16:58:06',0),
('89b4d7dc-5225-4070-b79e-379d3d53d902',NULL,0,'2023-10-07 00:43:16','2023-10-07 00:43:16',0),
('9bbcd512-4bc6-4ab8-8a76-2d66023ab5ef','973ecf89-38ff-11ed-aed0-040300000000',0,'2023-02-23 16:54:27','2023-02-23 22:54:17',0),
('9e251bd3-949b-434a-8226-a209e87504d1','8d2de28e-c9b6-11ed-afa1-0242ac120002',1,'2023-03-29 19:35:23','2024-01-25 16:55:38',0),
('a1799135-eab1-4a55-bb02-4c8fd7e1b31f','ffcc48cb-3087-11ed-aed0-040300000000',0,'2023-02-21 02:15:08','2023-02-23 15:49:11',0),
('b9280f82-ef4a-45d3-9536-e076c38c4aae','dbce727c-780d-11ed-aad1-040300000000',0,'2023-02-23 00:11:28','2023-03-13 17:25:05',0),
('bd5232b9-f9fd-437a-b382-2742acd6a272','dbce727c-780d-11ed-aad1-040300000000',0,'2023-03-11 00:23:40','2023-03-11 00:23:40',0),
('c6451b18-bf43-4a57-80f6-7e4c8a02cb2e','7af0aa1e-70e8-11ed-a880-040300000000',0,'2023-02-23 17:11:29','2023-02-23 17:11:29',0),
('d65041db-9d6d-4251-a940-6d868f2f9956','x73ecf89-38ff-11ed-aed0-040300000000',0,'2023-02-23 17:06:49','2023-02-23 17:06:49',0),
('dedfdc03-c067-4f96-9a07-447c6c366961','884be320-b6cb-11ed-9bd4-2c4138b7dab1',1,'2023-03-15 16:23:20','2023-03-21 18:26:27',0),
('eb5b4ce0-5509-4a56-91d0-54403e12c252','47c46140-b148-11ed-afa1-0242ac120002',0,'2023-02-20 18:59:35','2023-02-20 18:59:46',0);
/*!40000 ALTER TABLE `Configuraciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DetalleAppTipoDoc`
--

DROP TABLE IF EXISTS `DetalleAppTipoDoc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DetalleAppTipoDoc` (
  `Id` char(36) NOT NULL DEFAULT uuid(),
  `IdApp` char(36) NOT NULL,
  `IdTipoDocumento` char(36) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DetalleAppTipoDoc`
--

LOCK TABLES `DetalleAppTipoDoc` WRITE;
/*!40000 ALTER TABLE `DetalleAppTipoDoc` DISABLE KEYS */;
INSERT INTO `DetalleAppTipoDoc` VALUES
('0eec11af-b30b-11ed-9bd4-2c4138b7dab1','ffcc48cb-3087-11ed-aed0-040300000000','dcaa95bf-a9ac-4ad8-a31c-44c74a8702a6','2023-02-22 23:45:59','2023-02-22 23:45:59'),
('2654a3ec-b39d-11ed-9bd4-2c4138b7dab1','7af0aa1e-70e8-11ed-a880-040300000000','0aca6b66-2a13-460b-9501-2bc2c603f251','2023-02-23 17:11:45','2023-02-23 17:11:45'),
('2a427697-b233-11ed-9bd4-2c4138b7dab1','ffcc48cb-3087-11ed-aed0-040300000000','7b372135-9921-488b-a3a6-bb3a5552ca24','2023-02-21 22:00:34','2023-02-21 22:00:34'),
('3ee00422-ae16-11ed-b719-2c4138b7dab1','cd9ca3cc-ad65-11ed-afa1-0242ac120002','fff34b1e-d958-430d-a701-4e1e65b286c0','2023-02-16 16:23:28','2023-02-16 16:23:28'),
('695c1485-c1b5-11ed-b789-2c4138b7dab1','dbce727c-780d-11ed-aad1-040300000000','86a5d20b-806a-4418-9a18-6b7753011a6b','2023-03-13 15:40:41','2023-03-13 15:40:41'),
('726df7e6-b221-11ed-9bd4-2c4138b7dab1','999db602-acbf-11ed-b719-2c4138b7dab1','54608ef8-3722-4f01-9943-21d319863f87','2023-02-21 19:53:44','2023-02-21 19:53:44'),
('7746ebdf-630b-11ee-a933-236cb4402701','973ecf89-38ff-11ed-aed0-040300000000','a9f6bfc2-5d00-4ca2-80f5-4f7a9f8a7e39','2023-10-04 22:15:26','2023-10-04 22:15:26'),
('83647c7c-ae1c-11ed-b719-2c4138b7dab1','cd9ca3cc-ad65-11ed-afa1-0242ac120002','22f74f1c-d5a3-4744-8888-85923a1f56af','2023-02-16 17:08:20','2023-02-16 17:08:20'),
('94df72ce-d30d-11ed-8002-d89d6776f970','8d2de28e-c9b6-11ed-afa1-0242ac120002','4cf07966-aef4-45a9-98c4-c91cb6601136','2023-04-04 17:24:39','2023-04-04 17:24:39'),
('9e47f648-d30d-11ed-8002-d89d6776f970','8d2de28e-c9b6-11ed-afa1-0242ac120002','b3b1f1bb-2c6a-4e8e-a730-6e7e52de6c4e','2023-04-04 17:24:55','2023-04-04 17:24:55'),
('9e54a29c-b22c-11ed-9bd4-2c4138b7dab1','ffcc48cb-3087-11ed-aed0-040300000000','dc50891d-5a1e-4306-b018-b678298fc099','2023-02-21 21:13:42','2023-02-21 21:13:42'),
('a679a0b3-b30e-11ed-9bd4-2c4138b7dab1','dbce727c-780d-11ed-aad1-040300000000','59c6641a-7f1b-4d18-adb1-85ff8c30a919','2023-02-23 00:11:42','2023-02-23 00:11:42'),
('b1cde3a7-ae2e-11ed-b719-2c4138b7dab1','999db602-acbf-11ed-b719-2c4138b7dab1','6f0c2daa-b3ac-49bb-bd09-4623e63c7f3b','2023-02-16 19:18:29','2023-02-16 19:18:29'),
('c094dc9f-b3be-11ed-9bd4-2c4138b7dab1','973ecf89-38ff-11ed-aed0-040300000000','aa01a265-a2f4-4d46-be0c-1fe37a5ea4fc','2023-02-23 21:12:17','2023-02-23 21:12:17'),
('c5a96051-b3aa-11ed-9bd4-2c4138b7dab1','973ecf89-38ff-11ed-aed0-040300000000','fb37feaa-efe8-40c3-b85d-80ca8ab66cf1','2023-02-23 18:49:16','2023-02-23 18:49:16'),
('ef233c3a-b3cb-11ed-9bd4-2c4138b7dab1','973ecf89-38ff-11ed-aed0-040300000000','3c3d8468-3f6f-4486-8f8f-0a45952e04a6','2023-02-23 22:46:39','2023-02-23 22:46:39');
/*!40000 ALTER TABLE `DetalleAppTipoDoc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DocumentosEnviados`
--

DROP TABLE IF EXISTS `DocumentosEnviados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DocumentosEnviados` (
  `Id` char(36) NOT NULL,
  `IdPathDoc` char(36) DEFAULT NULL,
  `IdUsuario` char(36) DEFAULT NULL,
  `Destinatarios` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`Destinatarios`)),
  `ConCopia` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`ConCopia`)),
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DocumentosEnviados`
--

LOCK TABLES `DocumentosEnviados` WRITE;
/*!40000 ALTER TABLE `DocumentosEnviados` DISABLE KEYS */;
INSERT INTO `DocumentosEnviados` VALUES
('06cbd899-402d-4a02-afd0-40845d198904','a9062320-d30c-11ed-8002-d89d6776f970','d8483c80-c9b4-11ed-afa1-0242ac120002','[{\"correo\":\"joseaguedosernameza@gmail.com\",\"IdUsuario\":\"d8483c80-c9b4-11ed-afa1-0242ac120002\",\"nombre_puesto\":\"Jos\\u00e9 Aguedo Serna Meza - GENERICO\"}]','[]','2023-04-04 17:18:53','2023-04-04 17:18:53'),
('08811eaa-34cc-4685-95fe-3fd327e0619b','307608e7-d311-11ed-8002-d89d6776f970','d8483c80-c9b4-11ed-afa1-0242ac120002','[{\"correo\":\"joseaguedosernameza@gmail.com\",\"IdUsuario\":\"d8483c80-c9b4-11ed-afa1-0242ac120002\",\"nombre_puesto\":\"Jos\\u00e9 Aguedo Serna Meza - GENERICO\"}]','[{\"correo\":\"mavega@cecapmex.com\",\"IdUsuario\":\"0c130706-7266-11ed-a880-040300000000\",\"nombre_puesto\":\"Angel Genaro Carreon Diaz - GENERICO\"}]','2023-04-04 17:51:00','2023-04-04 17:51:00'),
('19723a30-6bdd-4816-9bbe-4ea1e196ed6e','51c57a77-ee88-11ed-8002-d89d6776f970','d8483c80-c9b4-11ed-afa1-0242ac120002','[{\"correo\":\"aagarcia@cecapmex.com\",\"IdUsuario\":\"30adc962-7109-11ed-a880-040300000000\",\"nombre_puesto\":\"Distribuci\\u00f3n De Recursos -\"}]','[]','2023-05-09 16:42:26','2023-05-09 16:42:26'),
('1ba29c81-4203-432a-8fca-2ed8bdb38ce2','67d3013f-c4da-11ed-b789-2c4138b7dab1',NULL,'[{\"correo\":\"japerez@cecapmex.com\",\"IdUsuario\":\"a6860b44-3087-11ed-aed0-040300000000\",\"nombre_puesto\":\"Jos\\u00e9 A. P\\u00e9rez Alonso - DEV\"}]','[{\"correo\":\"jabustos@cecapmex.com\",\"IdUsuario\":\"5dbda069-b6ca-11ed-9bd4-2c4138b7dab1\",\"nombre_puesto\":\"Jonathan Bustos H - DEV\"},{\"correo\":\"joseaguedosernameza@gmail.com\",\"IdUsuario\":\"undefined\",\"nombre_puesto\":\"Jose serna meza -\"}]','2023-03-17 18:28:21','2023-03-17 18:28:21'),
('2cc669dd-2dc9-4201-afc4-945ccd0ea98d','f66cc3e4-cf33-11ed-8002-d89d6776f970','d8483c80-c9b4-11ed-afa1-0242ac120002','[{\"correo\":\"jaguedo@cecapmex.com\",\"IdUsuario\":\"d8483c80-c9b4-11ed-afa1-0242ac120002\",\"nombre_puesto\":\"Jos\\u00e9 Aguedo Serna Meza - GENERICO\"}]','[{\"correo\":\"jaguedo@cecapmex.com\",\"IdUsuario\":\"d8483c80-c9b4-11ed-afa1-0242ac120002\",\"nombre_puesto\":\"Jos\\u00e9 Aguedo Serna Meza - GENERICO\"}]','2023-03-30 20:59:29','2023-03-30 20:59:29'),
('3eb50049-c2fa-4be3-9e04-cce3cfeb49c6','400b0349-d312-11ed-8002-d89d6776f970','d8483c80-c9b4-11ed-afa1-0242ac120002','[{\"correo\":\"joseaguedosernameza@gmail.com\",\"IdUsuario\":\"d8483c80-c9b4-11ed-afa1-0242ac120002\",\"nombre_puesto\":\"Jos\\u00e9 Aguedo Serna Meza - GENERICO\"}]','[{\"correo\":\"aortiz@cecapmex.com\",\"IdUsuario\":\"09e620ae-b87d-11ed-8002-d89d6776f970\",\"nombre_puesto\":\"PEDRO HIGINIO SALAZAR OBREG\\u00d3N - GENERICO\"},{\"correo\":\"mavega@cecapmex.com\",\"IdUsuario\":\"0c130706-7266-11ed-a880-040300000000\",\"nombre_puesto\":\"Angel Genaro Carreon Diaz - GENERICO\"},{\"correo\":\"japerez@cecapmex.com\",\"IdUsuario\":\"209d29f5-71dc-11ed-a880-040300000000\",\"nombre_puesto\":\"Mario Alberto Inguanzo Vieyra - GENERICO\"},{\"correo\":\"jabustos@cecapmex.com\",\"IdUsuario\":\"2fad75f3-b79f-11ed-8002-d89d6776f970\",\"nombre_puesto\":\"Juan Fernando Ch\\u00e1vez Marroqu\\u00edn - GENERICO\"}]','2023-04-04 17:58:55','2023-04-04 17:58:55'),
('3f308cc9-76db-4534-a03e-27adc4c001fe','01ca9985-d3db-11ed-8002-d89d6776f970','d8483c80-c9b4-11ed-afa1-0242ac120002','[{\"correo\":\"joseaguedosernameza@gmail.com\",\"IdUsuario\":\"d8483c80-c9b4-11ed-afa1-0242ac120002\",\"nombre_puesto\":\"Jos\\u00e9 Aguedo Serna Meza - GENERICO\"}]','[]','2023-04-05 17:55:27','2023-04-05 17:55:27'),
('4b65868f-5d11-4500-bc22-c6ec3b4984ba','8b0ab7bb-d311-11ed-8002-d89d6776f970','d8483c80-c9b4-11ed-afa1-0242ac120002','[{\"correo\":\"joseaguedosernameza@gmail.com\",\"IdUsuario\":\"d8483c80-c9b4-11ed-afa1-0242ac120002\",\"nombre_puesto\":\"Jos\\u00e9 Aguedo Serna Meza - GENERICO\"}]','[{\"correo\":\"aortiz@cecapmex.com\",\"IdUsuario\":\"09e620ae-b87d-11ed-8002-d89d6776f970\",\"nombre_puesto\":\"PEDRO HIGINIO SALAZAR OBREG\\u00d3N - GENERICO\"},{\"correo\":\"mavega@cecapmex.com\",\"IdUsuario\":\"0c130706-7266-11ed-a880-040300000000\",\"nombre_puesto\":\"Angel Genaro Carreon Diaz - GENERICO\"},{\"correo\":\"japerez@cecapmex.com\",\"IdUsuario\":\"209d29f5-71dc-11ed-a880-040300000000\",\"nombre_puesto\":\"Mario Alberto Inguanzo Vieyra - GENERICO\"}]','2023-04-04 17:54:07','2023-04-04 17:54:07'),
('51a40856-62af-4936-8f72-24603fbbfd89','f08ed1ec-d269-11ed-8002-d89d6776f970','d8483c80-c9b4-11ed-afa1-0242ac120002','[{\"correo\":\"joseaguedosernameza@gmail.com\",\"IdUsuario\":\"d8483c80-c9b4-11ed-afa1-0242ac120002\",\"nombre_puesto\":\"Jos\\u00e9 Aguedo Serna Meza - GENERICO\"}]','[]','2023-04-03 21:55:38','2023-04-03 21:55:38'),
('53502ed7-ac19-4d94-8af5-f80c43000e50','76b04fe4-bdd3-11ed-b789-2c4138b7dab1','2fa57758-c4de-11ed-afa1-0242ac120002','[{\"correo\":\"joseaguedosernameza@gmail.com\",\"IdUsuario\":\"54cbec0a-c1ce-11ed-afa1-0242ac120002\",\"nombre_puesto\":\"Jose Aguedo - Desarrollador\"}]','[{\"correo\":\"mkcortes.86@gmail.com\",\"IdUsuario\":\"54cbef5c-c1ce-11ed-afa1-0242ac120002\",\"nombre_puesto\":\"Jose Serna - Ingeniero Software\"},{\"IdUsuario\":\"1d11dce0-bfa1-11ed-afa1-0242ac120002\",\"correo\":\"jaguedo@cecapmex.com\",\"nombre_puesto\":\"Jose Meza - DevOps operations\"}]','2023-03-17 16:21:47','2023-03-17 16:21:47'),
('5cb40522-59ce-4fb9-ae15-cb075b7496e0','141fa7e7-d3da-11ed-8002-d89d6776f970','d8483c80-c9b4-11ed-afa1-0242ac120002','[{\"correo\":\"joseaguedosernameza@gmail.com\",\"IdUsuario\":\"d8483c80-c9b4-11ed-afa1-0242ac120002\",\"nombre_puesto\":\"Jos\\u00e9 Aguedo Serna Meza - GENERICO\"}]','[]','2023-04-05 17:49:57','2023-04-05 17:49:57'),
('5cc70c91-0845-48b1-9385-83b645657503','76b04fe4-bdd3-11ed-b789-2c4138b7dab1','2fa57758-c4de-11ed-afa1-0242ac120002','[{\"correo\":\"joseaguedosernameza@gmail.com\",\"IdUsuario\":\"54cbec0a-c1ce-11ed-afa1-0242ac120002\",\"nombre_puesto\":\"Jose Aguedo - Desarrollador\"}]','[{\"correo\":\"mkcortes.86@gmail.com\",\"IdUsuario\":\"54cbef5c-c1ce-11ed-afa1-0242ac120002\",\"nombre_puesto\":\"Jose Serna - Ingeniero Software\"},{\"IdUsuario\":\"1d11dce0-bfa1-11ed-afa1-0242ac120002\",\"correo\":\"jaguedo@cecapmex.com\",\"nombre_puesto\":\"Jose Meza - DevOps operations\"}]','2023-03-17 16:25:39','2023-03-17 16:25:39'),
('5ee80e16-0a52-4741-abee-759b2b586523','76b04fe4-bdd3-11ed-b789-2c4138b7dab1',NULL,'[{\"correo\":\"joseaguedosernameza@gmail.com\",\"IdUsuario\":\"54cbec0a-c1ce-11ed-afa1-0242ac120002\",\"nombre_puesto\":\"Jose Aguedo - Desarrollador\"}]','[{\"correo\":\"mkcortes.86@gmail.com\",\"IdUsuario\":\"54cbef5c-c1ce-11ed-afa1-0242ac120002\",\"nombre_puesto\":\"Jose Serna - Ingeniero Software\"},{\"IdUsuario\":\"1d11dce0-bfa1-11ed-afa1-0242ac120002\",\"correo\":\"jaguedo@cecapmex.com\",\"nombre_puesto\":\"Jose Meza - DevOps operations\"}]','2023-03-17 16:07:03','2023-03-17 16:07:03'),
('6b9488c3-4f43-48dd-a6a5-6fad5113b67d','3bf9286d-ce69-11ed-8002-d89d6776f970','d8483c80-c9b4-11ed-afa1-0242ac120002','[{\"correo\":\"jaguedo@cecapmex.com\",\"IdUsuario\":\"d8483c80-c9b4-11ed-afa1-0242ac120002\",\"nombre_puesto\":\"Jos\\u00e9 Aguedo Serna Meza - GENERICO\"}]','[]','2023-03-30 21:14:35','2023-03-30 21:14:35'),
('717a59a6-3865-4b17-ae7c-958cccb3e5b5','76b04fe4-bdd3-11ed-b789-2c4138b7dab1',NULL,'[{\"correo\":\"joseaguedosernameza@gmail.com\",\"IdUsuario\":\"54cbec0a-c1ce-11ed-afa1-0242ac120002\",\"nombre_puesto\":\"Jose Aguedo - Desarrollador\"}]','[{\"correo\":\"mkcortes.86@gmail.com\",\"IdUsuario\":\"54cbef5c-c1ce-11ed-afa1-0242ac120002\",\"nombre_puesto\":\"Jose Serna - Ingeniero Software\"},{\"IdUsuario\":\"1d11dce0-bfa1-11ed-afa1-0242ac120002\",\"correo\":\"jaguedo@cecapmex.com\",\"nombre_puesto\":\"Jose Meza - DevOps operations\"}]','2023-03-17 16:10:16','2023-03-17 16:10:16'),
('742b3962-1dd3-40d9-8b6c-420eb0df702f','cd5549dc-ce67-11ed-8002-d89d6776f970','d8483c80-c9b4-11ed-afa1-0242ac120002','[{\"correo\":\"joseaguedosernameza@gmail.com\",\"IdUsuario\":\"d8483c80-c9b4-11ed-afa1-0242ac120002\",\"nombre_puesto\":\"Jos\\u00e9 Aguedo Serna Meza - GENERICO\"}]','[{\"correo\":\"jaguedo@cecapmex.com\",\"IdUsuario\":\"09e620ae-b87d-11ed-8002-d89d6776f970\",\"nombre_puesto\":\"PEDRO HIGINIO SALAZAR OBREG\\u00d3N - GENERICO\"}]','2023-04-04 17:41:47','2023-04-04 17:41:47'),
('75815cad-aacc-40d0-b972-797939981128','1eed38e5-d3ca-11ed-8002-d89d6776f970','d8483c80-c9b4-11ed-afa1-0242ac120002','[{\"correo\":\"joseaguedosernameza@gmail.com\",\"IdUsuario\":\"d8483c80-c9b4-11ed-afa1-0242ac120002\",\"nombre_puesto\":\"Jos\\u00e9 Aguedo Serna Meza - GENERICO\"}]','[]','2023-04-05 15:56:09','2023-04-05 15:56:09'),
('7d0c8d5b-a57b-45c6-a2af-6b5a51f247eb','0a419dd8-d30f-11ed-8002-d89d6776f970','d8483c80-c9b4-11ed-afa1-0242ac120002','[{\"correo\":\"joseaguedosernameza@gmail.com\",\"IdUsuario\":\"d8483c80-c9b4-11ed-afa1-0242ac120002\",\"nombre_puesto\":\"Jos\\u00e9 Aguedo Serna Meza - GENERICO\"}]','[{\"correo\":\"jabustos@cecapmex.com\",\"IdUsuario\":\"09e620ae-b87d-11ed-8002-d89d6776f970\",\"nombre_puesto\":\"PEDRO HIGINIO SALAZAR OBREG\\u00d3N - GENERICO\"}]','2023-04-04 17:35:38','2023-04-04 17:35:38'),
('8122fc71-7187-4bad-a4ec-02257d46ec71','76b04fe4-bdd3-11ed-b789-2c4138b7dab1',NULL,'[{\"correo\":\"joseaguedosernameza@gmail.com\",\"IdUsuario\":\"54cbec0a-c1ce-11ed-afa1-0242ac120002\",\"nombre_puesto\":\"Jose Aguedo - Desarrollador\"}]','[{\"correo\":\"mkcortes.86@gmail.com\",\"IdUsuario\":\"54cbef5c-c1ce-11ed-afa1-0242ac120002\",\"nombre_puesto\":\"Jose Serna - Ingeniero Software\"},{\"IdUsuario\":\"1d11dce0-bfa1-11ed-afa1-0242ac120002\",\"correo\":\"jaguedo@cecapmex.com\",\"nombre_puesto\":\"Jose Meza - DevOps operations\"}]','2023-03-17 16:15:33','2023-03-17 16:15:33'),
('86b1a230-3b1d-4e89-aac0-2715dc6e4fe7','c7cfe258-c515-11ed-b789-2c4138b7dab1','a77a303c-3a98-11ed-a261-0242ac120002','[{\"correo\":\"japerez@cecapmex.com\",\"IdUsuario\":\"a6860b44-3087-11ed-aed0-040300000000\",\"nombre_puesto\":\"Jos\\u00e9 A. P\\u00e9rez Alonso - DEV\"}]','[]','2023-03-21 18:23:00','2023-03-21 18:23:00'),
('9c91de03-7520-4cea-9115-45d0f39f74fe','1786bd05-d304-11ed-8002-d89d6776f970','d8483c80-c9b4-11ed-afa1-0242ac120002','[{\"correo\":\"joseaguedosernameza@gmail.com\",\"IdUsuario\":\"d8483c80-c9b4-11ed-afa1-0242ac120002\",\"nombre_puesto\":\"Jos\\u00e9 Aguedo Serna Meza - GENERICO\"}]','[]','2023-04-04 16:17:21','2023-04-04 16:17:21'),
('a0625643-2a4d-4808-a436-6df9ed3026fd','76b04fe4-bdd3-11ed-b789-2c4138b7dab1',NULL,'[{\"correo\":\"joseaguedosernameza@gmail.com\",\"IdUsuario\":\"54cbec0a-c1ce-11ed-afa1-0242ac120002\"}]','[{\"correo\":\"mkcortes.86@gmail.com\",\"IdUsuario\":\"54cbef5c-c1ce-11ed-afa1-0242ac120002\"},{\"IdUsuario\":\"1d11dce0-bfa1-11ed-afa1-0242ac120002\",\"correo\":\"jaguedo@cecapmex.com\"}]','2023-03-17 16:00:09','2023-03-17 16:00:09'),
('a5d77864-feb0-4775-8974-2f14f1fdc9fb','0893105b-c516-11ed-b789-2c4138b7dab1','5dbda069-b6ca-11ed-9bd4-2c4138b7dab1','[{\"correo\":\"jabustos@cecapmex.com\",\"IdUsuario\":\"5dbda069-b6ca-11ed-9bd4-2c4138b7dab1\",\"nombre_puesto\":\"Jonathan Bustos H - DEV\"}]','[{\"correo\":\"joseaguedosernameza@gmail.com\",\"IdUsuario\":\"a77a303c-3a98-11ed-a261-0242ac120002\",\"nombre_puesto\":\"Jose serna meza -\"},{\"correo\":\"japerez@cecapmex.com\",\"IdUsuario\":\"undefined\",\"nombre_puesto\":\"Jos\\u00e9 A. P\\u00e9rez Alonso - DEV\"}]','2023-03-17 22:58:22','2023-03-17 22:58:22'),
('ab6935f4-fa11-4e3a-8a40-fbf996f23572','f9d3a2a2-c4f5-11ed-b789-2c4138b7dab1','5dbda069-b6ca-11ed-9bd4-2c4138b7dab1','[{\"correo\":\"jabustos@cecapmex.com\",\"IdUsuario\":\"5dbda069-b6ca-11ed-9bd4-2c4138b7dab1\",\"nombre_puesto\":\"Jonathan Bustos H - DEV\"}]','[{\"correo\":\"joseaguedosernameza@gmail.com\",\"IdUsuario\":\"a77a303c-3a98-11ed-a261-0242ac120002\",\"nombre_puesto\":\"Jose serna meza -\"}]','2023-03-17 19:46:25','2023-03-17 19:46:25'),
('b4fde87e-bf60-4b0f-b933-796056b55fc6','11f0f254-eaae-11ed-8002-d89d6776f970','d8483c80-c9b4-11ed-afa1-0242ac120002','[{\"correo\":\"joseaguedosernameza@gmail.com\",\"IdUsuario\":\"d8483c80-c9b4-11ed-afa1-0242ac120002\",\"nombre_puesto\":\"Jos\\u00e9 Aguedo Serna Meza - Desarrollador\"}]','[]','2023-05-04 19:02:17','2023-05-04 19:02:17'),
('b8379e1a-b3e8-49c5-859b-4c8b9fd02c0b','61e4a9eb-d310-11ed-8002-d89d6776f970','d8483c80-c9b4-11ed-afa1-0242ac120002','[{\"correo\":\"joseaguedosernameza@gmail.com\",\"IdUsuario\":\"d8483c80-c9b4-11ed-afa1-0242ac120002\",\"nombre_puesto\":\"Jos\\u00e9 Aguedo Serna Meza - GENERICO\"}]','[{\"correo\":\"aortiz@cecapmex.com\",\"IdUsuario\":\"09e620ae-b87d-11ed-8002-d89d6776f970\",\"nombre_puesto\":\"PEDRO HIGINIO SALAZAR OBREG\\u00d3N - GENERICO\"}]','2023-04-04 17:45:03','2023-04-04 17:45:03'),
('c76d81ef-c4bc-4843-a710-18a8c7dda6cc','3a38998b-d3cf-11ed-8002-d89d6776f970','d8483c80-c9b4-11ed-afa1-0242ac120002','[{\"correo\":\"joseaguedosernameza@gmail.com\",\"IdUsuario\":\"d8483c80-c9b4-11ed-afa1-0242ac120002\",\"nombre_puesto\":\"Jos\\u00e9 Aguedo Serna Meza - GENERICO\"}]','[]','2023-04-05 16:31:08','2023-04-05 16:31:08'),
('cb736b29-717c-4096-9e37-6e083076724e','358fbce4-eebe-11ed-8002-d89d6776f970','d8483c80-c9b4-11ed-afa1-0242ac120002','[{\"correo\":\"aagarcia@cecapmex.com\",\"IdUsuario\":\"30adc962-7109-11ed-a880-040300000000\",\"nombre_puesto\":\"Adolfo Lopez Recursos -\"}]','[{\"correo\":\"aagarcia@cecapmex.com\",\"IdUsuario\":\"30adc962-7109-11ed-a880-040300000000\",\"nombre_puesto\":\"Adolfo Lopez Recursos -\"}]','2023-05-09 23:26:54','2023-05-09 23:26:54'),
('e24ba7b9-32ca-4146-a27e-f442ebaf0263','7820f112-c4f2-11ed-b789-2c4138b7dab1','5dbda069-b6ca-11ed-9bd4-2c4138b7dab1','[{\"correo\":\"joseaguedosernameza@gmail.com\",\"IdUsuario\":\"a77a303c-3a98-11ed-a261-0242ac120002\",\"nombre_puesto\":\"Jose serna meza -\"}]','[]','2023-03-17 23:01:43','2023-03-17 23:01:43'),
('ec768241-b7b4-48a1-972b-f434e83a4865','76b04fe4-bdd3-11ed-b789-2c4138b7dab1','2fa57758-c4de-11ed-afa1-0242ac120002','[{\"correo\":\"joseaguedosernameza@gmail.com\",\"IdUsuario\":\"54cbec0a-c1ce-11ed-afa1-0242ac120002\",\"nombre_puesto\":\"Jose Aguedo - Desarrollador\"}]','[{\"correo\":\"mkcortes.86@gmail.com\",\"IdUsuario\":\"54cbef5c-c1ce-11ed-afa1-0242ac120002\",\"nombre_puesto\":\"Jose Serna - Ingeniero Software\"},{\"IdUsuario\":\"1d11dce0-bfa1-11ed-afa1-0242ac120002\",\"correo\":\"jaguedo@cecapmex.com\",\"nombre_puesto\":\"Jose Meza - DevOps operations\"}]','2023-03-17 16:16:23','2023-03-17 16:16:23'),
('f8a62750-fb9b-4ed2-9735-0a1c2f63ac78','891d01fe-d3c8-11ed-8002-d89d6776f970','d8483c80-c9b4-11ed-afa1-0242ac120002','[{\"correo\":\"joseaguedosernameza@gmail.com\",\"IdUsuario\":\"d8483c80-c9b4-11ed-afa1-0242ac120002\",\"nombre_puesto\":\"Jos\\u00e9 Aguedo Serna Meza - GENERICO\"}]','[]','2023-04-05 15:43:42','2023-04-05 15:43:42');
/*!40000 ALTER TABLE `DocumentosEnviados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EstatusBandejas`
--

DROP TABLE IF EXISTS `EstatusBandejas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EstatusBandejas` (
  `Id` char(36) NOT NULL,
  `IdEstatusBandeja` char(36) DEFAULT NULL,
  `Nombre` varchar(255) DEFAULT NULL,
  `Descripcion` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EstatusBandejas`
--

LOCK TABLES `EstatusBandejas` WRITE;
/*!40000 ALTER TABLE `EstatusBandejas` DISABLE KEYS */;
INSERT INTO `EstatusBandejas` VALUES
('ac4967f0-bdc8-11ed-afa1-0242ac120002','ac4967f0-bdc8-11ed-afa1-0242ac120002','Por enviar',NULL,'2023-03-08 09:55:50','2023-03-08 09:55:53'),
('ac496de0-bdc8-11ed-afa1-0242ac120002','ac496de0-bdc8-11ed-afa1-0242ac120002','Enviados',NULL,'2023-03-08 09:55:56','2023-03-08 09:55:59'),
('ac49701a-bdc8-11ed-afa1-0242ac120002','ac49701a-bdc8-11ed-afa1-0242ac120002','Recibidos',NULL,'2023-03-08 09:56:02','2023-03-08 09:56:05'),
('ac4971fa-bdc8-11ed-afa1-0242ac120002','ac4971fa-bdc8-11ed-afa1-0242ac120002','Histórico',NULL,'2023-03-08 09:53:19','2023-03-08 09:53:22');
/*!40000 ALTER TABLE `EstatusBandejas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FirmaDetalle`
--

DROP TABLE IF EXISTS `FirmaDetalle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FirmaDetalle` (
  `Id` char(36) NOT NULL,
  `SerialCertificado` varchar(100) NOT NULL,
  `Rfc` varchar(18) NOT NULL,
  `NumeroOficio` varchar(50) NOT NULL,
  `Asunto` varchar(500) NOT NULL,
  `Destinatario` varchar(1000) NOT NULL,
  `Ccp` varchar(1000) DEFAULT NULL,
  `CreadoPor` char(36) NOT NULL,
  `FechaFirma` datetime NOT NULL,
  `IdApp` varchar(36) NOT NULL,
  `Deleted` tinyint(1) NOT NULL DEFAULT 0,
  `DocumentoGenerado` tinyint(4) DEFAULT NULL,
  `IdFirmaOrigen` char(36) DEFAULT NULL COMMENT 'id generada desde front react',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `token` longtext DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  KEY `FK1_Creado_Central` (`CreadoPor`) USING BTREE,
  KEY `FK2_App_Central` (`IdApp`) USING BTREE,
  CONSTRAINT `FK1_Creado_Central` FOREIGN KEY (`CreadoPor`) REFERENCES `TiCentral`.`Usuarios` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK2_App_Central` FOREIGN KEY (`IdApp`) REFERENCES `TiCentral`.`Apps` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FirmaDetalle`
--

LOCK TABLES `FirmaDetalle` WRITE;
/*!40000 ALTER TABLE `FirmaDetalle` DISABLE KEYS */;
INSERT INTO `FirmaDetalle` VALUES
('0ac09aa2-3c38-4892-9a66-f9be75a9a3dc','3030303031303030303030353135333834313233','GOTJ971127BF8','OFICIO','OFICIO','1','1','d8483c80-c9b4-11ed-afa1-0242ac120002','2023-05-04 00:00:00','8d2de28e-c9b6-11ed-afa1-0242ac120002',0,1,NULL,'2023-05-04 19:35:16','2023-05-04 19:35:18','NheloTcDD26ioD4SKHohuqFdyXF773mtkk5oS/FvPJ8vR3eONTGXlTTVNis+SPpCybhxLzazwG2YxJW5lN0mqVChz6TFSbG/aZ7omi8v4x4qQA9GXcn6s/+6QodY+mVRaO1Kxdlo+tg1a7FXoTYQOlYOYE7GV23WA8A8BpZcu0PRJML8r/YVqpe0mWuNfwZnzP/8sfnsoSBMCanQaGpqb8o2FZ9F2IA08C493v4rOxqgAkH1R7eeSWlHb3J51faaJ95mJMZ259zEXs/JpZIDuv52AAphS5qEnnstfxj5oMgAVXjCOqblMxLSrFyY/QFOn/9WpL9jBgBUa6aHOwcE8A=='),
('1151968f-a90c-4733-91b0-414beada0915','3030303031303030303030353135333834313233','GOTJ971127BF8','2023116','2023116','1','1','d8483c80-c9b4-11ed-afa1-0242ac120002','2023-05-09 00:00:00','8d2de28e-c9b6-11ed-afa1-0242ac120002',0,1,NULL,'2023-05-09 23:04:11','2023-05-09 23:04:13','lF7icudF4dWLgbcfVYuIM4M6+30QkYcLYuHPE+A2RV04I8JYLOIrCcgVRF6JYn3Ay3p5tGzacqJUmKewDwi+bLt9RXL8M7non9gUWCP4qxxkey1SWLaAFWYE51ZpW/tmiQvTvDItBh7NnFrVsa0w3pgR6O+OUo8EG9Oil3vkQYjRXqXBTaeOvLg5JqIvj75oahxvrd6L5PTMZ+Z88sNuIGWCVQ5av38/Af1LzrJHvAZuVSedLAX9O3aUvcl9j1Lx5ekVqve4v3QcOw4bQc0HtoU00NwGgrlSGGqP373+DzJEgJf7zgNEmXy4mwSLzgL3PTsVYIYapk6DkvX8B++lIg=='),
('11a8168f-d380-411b-8891-74ed35643c10','3030303031303030303030353135333834313233','GOTJ971127BF8','REFMAY2023','REFMAY2023','1','1','d8483c80-c9b4-11ed-afa1-0242ac120002','2023-05-04 00:00:00','8d2de28e-c9b6-11ed-afa1-0242ac120002',0,NULL,NULL,'2023-05-04 19:15:39','2023-05-04 19:15:40','VaDj8OVroQyawcwYScyBOnRgADqJO0FvWqbjvni8wRyHZ4XXXpIaySp9fILdbkiEikLdB5rBW8YD4cMrIvUSZsDToZ3MFDidqI+bW1zrO8HFPdS53spEq9o8XgVLSBCmglo/C0JC1EcVg1gszh0WdOtCOTkhcnjSIKIyQ9ZaTf0lryeH/0dNfGD43UinO6jk1LLoGu5f3r7373QXj+2N2xo4yfVfH3ZmLzM/1PD3A5BvsxKgPPIE5GLmMAmjWEamvo8gZCjyYvd04/aOzK/RrS17Kc64EHmB4iIE2+V+hBTbypz1ruqBndEKSObgAR8VHrQ7/naca/l8MCURNYyNHg=='),
('1a0ddd58-11d4-42b8-b2a9-38c77f0fc823','3030303031303030303030353135333834313233','GOTJ971127BF8','prueba','firmar','1','1','d402cfd3-0ef4-11ee-8002-d89d6776f970','2023-10-04 14:38:33','973ecf89-38ff-11ed-aed0-040300000000',0,NULL,NULL,'2023-10-04 14:38:33','2023-10-04 14:38:33',NULL),
('23c1e706-0751-4de3-aacf-70fcf61985f7','3030303031303030303030353135333834313233','GOTJ971127BF8','059/UIFP/SFYTGE/2023','Se asigna clave de registro en cartera','1','1','d402cfd3-0ef4-11ee-8002-d89d6776f970','2023-10-04 00:00:00','973ecf89-38ff-11ed-aed0-040300000000',0,1,NULL,'2023-10-04 22:05:17','2023-10-04 22:05:20','DtPyhqS99dB76aVvV/6vRbSf93UqMTmtBzA6d9suxddU8amA4kLq1Qj758KEX7Ewm5wbCIp44W2XMLd4Y2R+f2zzaCA2P5BfgrCgPEDDGpHUiWEW5pXSjbWw1GlZRiQELVatpYXgA2kmgWgPgiLBINmV0FDLtopJkwJ0rwt6icR1YrRurulxsgTOePkdwwTQZYBbzbsZhErn2qkCS58y1HXCGvlEum22Vo60AaIx+NjuhwI2NUSPkerA8ptETcPwVVBVMslqPq/sqMkfNYqZdyfrR+P5K5D2VMlBv3KjzD7I+hBhB8Yi4yNW/2596Q0qEp9pRrWuYIxmhKe1T1Ey3A=='),
('4b802c51-2823-49f4-9ec9-0363c376ace0','3030303031303030303030353135333834313233','GOTJ971127BF8','Documento generado por el sistema','Documento generado por el sistema','1','1','d8483c80-c9b4-11ed-afa1-0242ac120002','2023-10-10 00:00:00','8d2de28e-c9b6-11ed-afa1-0242ac120002',0,1,NULL,'2023-10-10 23:11:29','2023-10-10 23:11:32','anHlA0mrnH/tM3KjD5hJyBMm5znDB3lcPLanzn8RfL7XWtViyzwrsO6C6kBUtAAsY7omdgYB6F8GnBspaID7nzFW+1oiggYf5DfyNUydXTvNzvYMT59K/a0be5/2qEMZb7+entIuJgz1CVLKvY1HYAsU2D0XL25qZpqx2kYpA9Vk5ezxI4OMnu0edS040+ceae4BtwdOqFJi4yAhnBFbiutn25vwzEHcou5XpyRmAXrMUxGgJO5adZVUm8tmjM77NBiU7OuBiTJAygG6oiWHTRzX0LGYYjVONHo7l2DNNm6XWzC8+Pu7LM2+IhDtrOJPVgDhkVcqJwZCm1RpKTS73w=='),
('503e9738-b7f4-4ebf-b86c-bd41d6999f35','3030303031303030303030353135333834313233','GOTJ971127BF8','OFMA723','OFMA723','1','1','d8483c80-c9b4-11ed-afa1-0242ac120002','2023-05-04 00:00:00','8d2de28e-c9b6-11ed-afa1-0242ac120002',0,NULL,NULL,'2023-05-04 19:09:33','2023-05-04 19:09:33','DoiVaSYfb9J26VgWh6H3A5Ys/y2/gZUyVCMfdaxpK71Kx3yBzdYwT41Nus/Dl4L4CWxoZSL0AhJEqfXTDzF23MZqMq4jYYEnuHo8UHEVNvOdGAql+8f1nGns/nucLiLLkGU0i6aXplBn/uO3ZpJIeSt3tuunNUkSCa/rhKvtbdK8lrQB9OAe7378UiAT/ALXZfTmq9y23IiWkFCJNKWHRCDHEiy+DaG6Gc8dfEHqAZ/SGK8SxxKeLJHi8a5Sffb607U9ogzoeKu131J4RBmDjg3htlDK86JnF0HmOpprnwZ43hShGwZ9vHvhcQLvIxmpkC+NFW8nQ8SnzTnRsP9KRw=='),
('52ef6c5e-b3c9-4de0-b5b4-68d90d3628f6','3030303031303030303030353135333834313233','GOTJ971127BF8','O59/UIFP/SFYTGE/2023','Se asigna clave de registro en cartera','1','1','d402cfd3-0ef4-11ee-8002-d89d6776f970','2023-10-04 00:00:00','973ecf89-38ff-11ed-aed0-040300000000',0,NULL,NULL,'2023-10-04 22:00:59','2023-10-04 22:00:59',NULL),
('5a2e3002-0710-406e-920b-acbf85339f06','3030303031303030303030353135333834313233','GOTJ971127BF8','O59/UIFP/SFYTGE/2023','Se asigna clave de registro en cartera','1','1','d402cfd3-0ef4-11ee-8002-d89d6776f970','2023-10-04 00:00:00','973ecf89-38ff-11ed-aed0-040300000000',0,NULL,NULL,'2023-10-04 21:51:17','2023-10-04 21:51:17',NULL),
('5d31e947-7449-416a-b774-78f1a3792aed','3030303031303030303030353135333834313233','GOTJ971127BF8','202316','2023166','1','1','d8483c80-c9b4-11ed-afa1-0242ac120002','2023-05-09 00:00:00','8d2de28e-c9b6-11ed-afa1-0242ac120002',0,1,NULL,'2023-05-09 23:07:35','2023-05-09 23:07:36','LTgNzROHcz2y2Iwf+/BdJ3vqzP9PAN3Pz57t6mPHztH/hARtng0+jaVx+fAHro0BxhSLi2tSWC2FzXTqF4D6jv7ywj1hG4Cy6lqC/cdk8vi7ekwViN+57AttQVSjPDxsRvNP+Xis77nE+UfmaIwibBU0t5uFQGQqP6ULRSVEHb2fll89JQ+aW+7cbkrMiASV7gERnz37vCgU11VfSDrzqK9zIsu2FClw//wcLPUlKX/usHG+CfeXbWItWTuOL/kgN3wCSR5XYky2j5Wd7z0E389IpdtODwaOsNvwTpWkqgS2Pz8FIzHk9WNtnJENaAMtPBmo0GOPbZw/ZOjiIKySng=='),
('61b07418-32b9-47c8-95a8-8e62a1856d47','3030303031303030303030353135333834313233','GOTJ971127BF8','REFMAY2023','REFMAY2023','1','1','d8483c80-c9b4-11ed-afa1-0242ac120002','2023-05-04 00:00:00','8d2de28e-c9b6-11ed-afa1-0242ac120002',0,NULL,NULL,'2023-05-04 19:15:54','2023-05-04 19:15:57','VaDj8OVroQyawcwYScyBOnRgADqJO0FvWqbjvni8wRyHZ4XXXpIaySp9fILdbkiEikLdB5rBW8YD4cMrIvUSZsDToZ3MFDidqI+bW1zrO8HFPdS53spEq9o8XgVLSBCmglo/C0JC1EcVg1gszh0WdOtCOTkhcnjSIKIyQ9ZaTf0lryeH/0dNfGD43UinO6jk1LLoGu5f3r7373QXj+2N2xo4yfVfH3ZmLzM/1PD3A5BvsxKgPPIE5GLmMAmjWEamvo8gZCjyYvd04/aOzK/RrS17Kc64EHmB4iIE2+V+hBTbypz1ruqBndEKSObgAR8VHrQ7/naca/l8MCURNYyNHg=='),
('724bfa60-5c06-4cdc-94f8-a854fc02903b','3030303031303030303030353135333834313233','GOTJ971127BF8','documento firmado por el sistema','documento firmado por el sistema','1','1','d8483c80-c9b4-11ed-afa1-0242ac120002','2023-10-10 00:00:00','8d2de28e-c9b6-11ed-afa1-0242ac120002',0,1,NULL,'2023-10-10 22:49:09','2023-10-10 22:49:11','AUFoDV8FjwUvz3X4GVeiJbZNyEB/oI575mEp0pscgjKR08TjVwtL2KrKRsgs1leWJSkiTObdZtiryAvmz/xtwVnUSk9ZeQuC332OFpg06H0FvDZxB/krGO3cKwkENd0nUGpXTOb+I5t7NCnzVJ//BueFhWJZnDv98ItRufcnu/L0vlT4w78GJi2Gf01T968KgHHgdoie35Y8M4+HWo9Ys3s2RtuIRyZwTVH5OecXnkVij0H/niB6+V1KXhvaReUCSkLtAqAsr3Vrv1TLuYaas61ORMR997QV06HecT30p5ZODT91sZ3KPMzvtjQmOj+SUCsW5zlCF2XSvQ+eKP1How=='),
('753bfda4-1f9d-46b8-80ab-fcf1af46f412','3030303031303030303030353135333834313233','GOTJ971127BF8','O59/UIFP/SFYTGE/2023','Se asigna clave de registro en cartera','1','1','d402cfd3-0ef4-11ee-8002-d89d6776f970','2023-10-04 00:00:00','973ecf89-38ff-11ed-aed0-040300000000',0,NULL,NULL,'2023-10-04 21:56:42','2023-10-04 21:56:42',NULL),
('77a3dcbd-7b8f-4145-bab5-4761f4122e43','3030303031303030303030353135333834313233','GOTJ971127BF8','Test','Test','1','1','0f2aa4d5-8968-11ee-9d15-d89d6776f970','2024-01-25 00:00:00','8d2de28e-c9b6-11ed-afa1-0242ac120002',0,1,NULL,'2024-01-25 15:48:41','2024-01-25 15:48:43','QFCO8y39YPS/ySv3EKWiX96lWtWUU6bw0HV0Nh0LshMsaYSodMXzVZdFSfwZadUl9OWY1jNw1qBmLHEmoPZUhJTd+Rb+T9nAWgbsHDxGxeF0SuCk1TSCDQAdhJOr7uEzKTtSpndQlL3t4wQYI5BTO5fBetFwHFR6jc6PKu4uFfDEg9WqFG3FSbXqp95EF7BCSnZi3F9WI+FRn4iFv1j+0p1/z0Pijsh9hzRJ9ZSjCDI9DaZmsBu8PlxfBvnT0VdrImclc6Rj23zZpS3NxfQvwJXOxs6DQ/iun8K04QwMzRA2UcXAgDekro90ANJyauiLvMw+2j++WA2h5TMThlWQig=='),
('7d177998-c985-40c4-9b49-5c75045c3bc6','3030303031303030303030353135333834313233','GOTJ971127BF8','OFMAY','OFMAY','1','1','d8483c80-c9b4-11ed-afa1-0242ac120002','2023-05-04 00:00:00','8d2de28e-c9b6-11ed-afa1-0242ac120002',0,1,NULL,'2023-05-04 19:01:53','2023-05-04 19:01:55','MOPCnyTY4OniolDYLoWRLPV+oIU6W3QhOGR0k63ZP+0PLjl9of75hEQl9Xcs9tRRCY7PYpmAn34TReMWPnHHdqTLLa68g/oiD1aeEh8UV9WJpThn9UiVGF/I/f/3v2rNwwCF9rJXRQ/gNFLcbyE0aYIOXTqgSrpomAaCOnkAzVzoSjGzAU0RgyuRO4TgsiDYqGq/ESc1TJEi1P0nbIECZVnW4pTAEqZp7HBHqQ8fL2n7ZghsWKRIWiOvC6UiV7qCPOSGwfdfgjmKG7GItvc6paPEZma3F/PIwVg0JzOsoILY3uDfn7y2umJdUoQ+98mHb8fMJkR7Lsykyv93aKmSOw=='),
('907753b1-d68a-4298-971d-49326808dbe4','3030303031303030303030353135333834313233','GOTJ971127BF8','O59/UIFP/SFYTGE/2023','Se asigna clave de registro en cartera','1','1','d402cfd3-0ef4-11ee-8002-d89d6776f970','2023-10-04 00:00:00','973ecf89-38ff-11ed-aed0-040300000000',0,NULL,NULL,'2023-10-04 22:01:24','2023-10-04 22:01:24',NULL),
('90e2818f-bddf-497b-a67c-50144c02eb69','3030303031303030303030353135333834313233','GOTJ971127BF8','O59/UIFP/SFYTGE/2023','Se asigna clave de registro en cartera','1','1','d402cfd3-0ef4-11ee-8002-d89d6776f970','2023-10-04 00:00:00','973ecf89-38ff-11ed-aed0-040300000000',0,NULL,NULL,'2023-10-04 21:59:09','2023-10-04 21:59:09',NULL),
('91affc1d-f1ff-48fe-b8aa-5e64990974f6','3030303031303030303030353135333834313233','GOTJ971127BF8','O59/UIFP/SFYTGE/2023','Se asigna clave de registro en cartera','1','1','d402cfd3-0ef4-11ee-8002-d89d6776f970','2023-10-04 00:00:00','973ecf89-38ff-11ed-aed0-040300000000',0,NULL,NULL,'2023-10-04 21:52:07','2023-10-04 21:52:07',NULL),
('970e0acc-8571-4b0b-a44d-b960bd49bdde','3030303031303030303030353135333834313233','GOTJ971127BF8','Documento firmado por el sistema','Documento firmado por el sistema','1','1','d8483c80-c9b4-11ed-afa1-0242ac120002','2023-10-10 00:00:00','8d2de28e-c9b6-11ed-afa1-0242ac120002',0,1,NULL,'2023-10-10 22:45:16','2023-10-10 22:45:18','BQT4fSUkc/XAfKHEA0HttS5AcWMfP2TwZA2vo8QUB7fTvci1J0lcrYk8O9eGjsF5dIHTEb/yQKAwFuuHZUh/SofYPBl7WW/2iLp72eLA2QM19pvy8Ayc3VQO7wzgAkTDNJ5ur0nIeeWqQTHZ30t6wNLYFNAx5ImyMuN4QpEEoaD2QQjpb9S9igNF9mE2Thv2z6TX0qZn7sQJ1+xXTG577Ihlxn9TB5kX2x/d9llaQK7z2AqdT9m4CQndFxkgJAFOx/OgDcVSq+kgeoUOFtHaJcGC8JDnr7G58DSO7/Rh5Zsv0p0E4yxf9Gl6U8iTpqOunk22z3hU/U7Fommpm5ObVQ=='),
('afad6557-fe6c-490b-aa6a-55cf0e3e9f7c','3030303031303030303030353135333834313233','GOTJ971127BF8','059/UIFP/SFYTGE/2023','Se asigna clave de registro en cartera','1','1','d402cfd3-0ef4-11ee-8002-d89d6776f970','2023-10-04 00:00:00','973ecf89-38ff-11ed-aed0-040300000000',0,1,NULL,'2023-10-04 22:23:18','2023-10-04 22:23:20','gW7hlYIn/5CA8glyM7Jrx6FBZF/gO+4eOOdJcd/hI+hGPy3c3jDex1pb5xObj/LDlI6SCOcLoWoyJMO8w0mqQsoYU6+vkIztgBilyEoiLjTPOy8d2iujD7re8A31MbuE4Yad7Xk1kI07WX5lgBhBgGM+A1zVWfZ7y4eOHkYEFbjNhNHlNGbhyHcdtXlD6IpV+t6h4WIyn4NeqC27q/4jGXGlOpYrhFIY6UNsL64MSRU6F8E4gD+mjMH1/XM0XBTI8cl5JJZ5x7Hts3x7/eJpn20Df2160PTTikMNfqc8ogJtiOwjhKFpOEApV/ymgz/LCTHytg0EtkJB6MT5LlcC9w=='),
('b5ff18fb-5362-4b68-b4f3-8379ad8a68c5','3030303031303030303030353135333834313233','GOTJ971127BF8','O59/UIFP/SFYTGE/2023','Se asigna clave de registro en cartera','1','1','d402cfd3-0ef4-11ee-8002-d89d6776f970','2023-10-04 00:00:00','973ecf89-38ff-11ed-aed0-040300000000',0,NULL,NULL,'2023-10-04 22:00:34','2023-10-04 22:00:34',NULL),
('c565a3b3-ae40-4186-8b1a-053f34a21665','3030303031303030303030353135333834313233','GOTJ971127BF8','Oficio Damop','Alta de Cuenta Bancaria','1','1','d402cfd3-0ef4-11ee-8002-d89d6776f970','2023-10-04 00:00:00','973ecf89-38ff-11ed-aed0-040300000000',0,1,NULL,'2023-10-04 22:08:26','2023-10-04 22:08:27','FUb3cHR2Shjg+Yj4Iy5QC88batMrFve7prCcWNqbCkra3cEPH/Dj+SYqu0HVkRRFWUAJHxUlSQcPUdFPpSCfnTBmnbRtJ2v6asvHVm7Fd8BSVX+1D8+WRGcG8EgA5GyOesaxKpFIeVE5e9NSC6wPD8ESWnnvc9iPXGIdDi4SuD1TYmZJog8eB1cnOMpr+z42SeprpUXXS3PDwBlCSzwDDCiU+MjmuL3xUuS6vCisTFhf2TSyjA5ah1vqrWBMkwk0Oj8n8gStc7dYECZGPwmSvQmkeIVp04LX1NrdQo5bVTMzny/FzZxYoKNo1eJJ2dBMulMD7Rr+h4Q/oNPNIynbJQ=='),
('c613006c-6f89-4267-9b68-a55248032baa','3030303031303030303030353135333834313233','GOTJ971127BF8','O59/UIFP/SFYTGE/2023','Se asigna clave de registro en cartera','1','1','d402cfd3-0ef4-11ee-8002-d89d6776f970','2023-10-04 00:00:00','973ecf89-38ff-11ed-aed0-040300000000',0,NULL,NULL,'2023-10-04 21:58:31','2023-10-04 21:58:31',NULL),
('d8aeb001-e864-4d72-9050-ec90f1554df9','3030303031303030303030353135333834313233','GOTJ971127BF8','OFPROD','OFPROD','1','1','d8483c80-c9b4-11ed-afa1-0242ac120002','2023-05-09 00:00:00','8d2de28e-c9b6-11ed-afa1-0242ac120002',0,1,NULL,'2023-05-09 16:41:49','2023-05-09 16:41:51','EYH8YHAlwKh9a8Kn/qlDrOPDzwDX2Liiex8MmYkDjHv77v1mxwe1qx1thyCux68XPfuwThA++Ao4behytEU4wWEa4+HPq1po6aVCJKTxxr69mCA9DUE7e8H7T0DJKUBkanzzBywRMYlUwRC/YhNPa6qJa1yCul1JhbJEv3VIm3QmX2FAjB6NtuMuvVhsKKjb97CpRCMMo0MXXB+EvwxnVMifGElC/ud4UtacY1U2YxT9bmfXlLcqOTV3hS4ASX7fzpcAm9PchUQolYK4D+k1seMrsAgb/VH357tp/D2+PG9igvlfn/mRQye/vHE1hmtQ8+gFrNlpETd+3RnMuN2sWA=='),
('e167e7ea-0c2e-4fe2-b163-0335b3ce5a40','3030303031303030303030353135333834313233','GOTJ971127BF8','0001/INAP/SFYTGE/2023','0001/INAP/SFYTGE/2023','1','1','d8483c80-c9b4-11ed-afa1-0242ac120002','2023-05-12 00:00:00','8d2de28e-c9b6-11ed-afa1-0242ac120002',0,1,NULL,'2023-05-12 21:41:10','2023-05-12 21:41:12','Hz7rBu3tkl8Lap1xbfmZ8KzCJV+j7YAKo7h8rUmonlCwAlXFF/n43N5nfSZ1BV4eNTzreXBB5pwl4m1dIZj/TbwZqNqS1/XjjxLqO7g+Y92qFIdWhK7Rj/c2NqYYA5YxCCrksAERWnUIZaNvAW7r8FlreyanTDGwNjRYvuNqLgBGxV8KGgeAZ6r0QluSAnfa/dvh8/IvoIHDLaXQMWPkB4P1W9slLX+u+yLKr1YyVsiKq4Bu3937nfwAse20Od3zsIOK9utYj/O+mX5zcK1eFq7HDUC23dP0TkSf28VniUGDV+/v2qKYTCmngFSKjB+bPP7oNXkLDrA2uYOBq/oQQg=='),
('e9882c84-5f59-4a3f-ab04-c63577c2a557','3030303031303030303030353135333834313233','GOTJ971127BF8','2023116','2023116','1','1','d8483c80-c9b4-11ed-afa1-0242ac120002','2023-05-09 00:00:00','8d2de28e-c9b6-11ed-afa1-0242ac120002',0,1,NULL,'2023-05-09 17:56:19','2023-05-09 17:56:20','XjdXE+4/rcq/3fGFFzbQYauFbk9rI6tZK9P8NweqDOapnmid8QpQapcQmX0C3wOn1dIBj8TuoMrYzJcfC4KNgNvdxtNASLGgQYAxgZjkUdvf3YSwSrjRMz4PLaX05RTdCO9B0YxQNeOzrPTqKYs34E6ppuNwLzCezYzyQ4+O8ZhU1fAn/gSvCwAJ8O/bgixCtLAFG0//T4jYXCJw3g0xcBOMxRzfRaJn1e7ODDQ9ffC7Z0cXfxHTsqtZpy9y7wPwN6EErlr6UFXMVhedaPs3TDswqSvExvC6ySxozjzd5Cm9mmsIjPgkq6rHSKTEdO+iji7q5YyjYv8xeqdNPJKVaQ=='),
('ece0fd4d-9a73-46e7-9483-469629490ef3','3030303031303030303030353135333834313233','GOTJ971127BF8','O59/UIFP/SFYTGE/2023','Se asigna clave de registro en cartera','1','1','d402cfd3-0ef4-11ee-8002-d89d6776f970','2023-10-04 00:00:00','973ecf89-38ff-11ed-aed0-040300000000',0,NULL,NULL,'2023-10-04 21:54:43','2023-10-04 21:54:43',NULL);
/*!40000 ALTER TABLE `FirmaDetalle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Parametros`
--

DROP TABLE IF EXISTS `Parametros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Parametros` (
  `Id` char(36) NOT NULL,
  `IdApp` varchar(255) DEFAULT NULL,
  `Nombre` varchar(255) DEFAULT NULL,
  `Descripcion` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Parametros`
--

LOCK TABLES `Parametros` WRITE;
/*!40000 ALTER TABLE `Parametros` DISABLE KEYS */;
INSERT INTO `Parametros` VALUES
('7ed4e339-fc7e-4fd7-b8b2-6798f5c4d228','1','leyenda','Ejemplo de la leyenda de la firma que se plasmará al momento de generar la firma en el documento y descargarlo, editable desde el apartado de configuración','2023-03-16 23:00:32','2023-03-16 23:27:49');
/*!40000 ALTER TABLE `Parametros` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PathDocumentos`
--

DROP TABLE IF EXISTS `PathDocumentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PathDocumentos` (
  `Id` char(36) NOT NULL DEFAULT uuid(),
  `IdEstatusBandeja` char(36) DEFAULT NULL,
  `IdTipoDocumento` char(36) DEFAULT NULL,
  `Path` varchar(5000) NOT NULL,
  `IdFirma` varchar(36) NOT NULL,
  `Nombre` varchar(256) NOT NULL COMMENT 'campo para guardar el nombre del archivo',
  `Fecha_doc` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  KEY `FK1_Path_Firma` (`IdFirma`) USING BTREE,
  CONSTRAINT `FK1_Path_Firma` FOREIGN KEY (`IdFirma`) REFERENCES `FirmaDetalle` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PathDocumentos`
--

LOCK TABLES `PathDocumentos` WRITE;
/*!40000 ALTER TABLE `PathDocumentos` DISABLE KEYS */;
INSERT INTO `PathDocumentos` VALUES
('0e32a510-630a-11ee-a933-236cb4402701','ac4967f0-bdc8-11ed-afa1-0242ac120002','fb37feaa-efe8-40c3-b85d-80ca8ab66cf1','http://10.210.26.26:8081/documentos/23c1e706-0751-4de3-aacf-70fcf61985f7','23c1e706-0751-4de3-aacf-70fcf61985f7','23c1e706-0751-4de3-aacf-70fcf61985f7','4-oct-2023','2023-10-04 22:05:20','2023-10-04 22:05:20',NULL),
('11f0f254-eaae-11ed-8002-d89d6776f970','ac496de0-bdc8-11ed-afa1-0242ac120002','54608ef8-3722-4f01-9943-21d319863f87','http://10.210.0.27:8081/documentos/7d177998-c985-40c4-9b49-5c75045c3bc6','7d177998-c985-40c4-9b49-5c75045c3bc6','7d177998-c985-40c4-9b49-5c75045c3bc6','2023-05-04','2023-05-04 19:01:55','2023-05-04 19:02:34','2023-05-04 19:02:34'),
('2548b39e-67c7-11ee-a933-236cb4402701','ac4967f0-bdc8-11ed-afa1-0242ac120002','b3b1f1bb-2c6a-4e8e-a730-6e7e52de6c4e','http://10.210.26.26:8081/documentos/724bfa60-5c06-4cdc-94f8-a854fc02903b','724bfa60-5c06-4cdc-94f8-a854fc02903b','724bfa60-5c06-4cdc-94f8-a854fc02903b','10-oct-2023','2023-10-10 22:49:11','2023-10-10 22:49:11',NULL),
('358fbce4-eebe-11ed-8002-d89d6776f970','ac4971fa-bdc8-11ed-afa1-0242ac120002','b3b1f1bb-2c6a-4e8e-a730-6e7e52de6c4e','http://10.210.0.27:8081/documentos/5d31e947-7449-416a-b774-78f1a3792aed','5d31e947-7449-416a-b774-78f1a3792aed','5d31e947-7449-416a-b774-78f1a3792aed','2023-05-09','2023-05-09 23:07:36','2023-05-09 23:29:28',NULL),
('44385308-67ca-11ee-a933-236cb4402701','ac4967f0-bdc8-11ed-afa1-0242ac120002','b3b1f1bb-2c6a-4e8e-a730-6e7e52de6c4e','http://10.210.26.26:8081/documentos/4b802c51-2823-49f4-9ec9-0363c376ace0','4b802c51-2823-49f4-9ec9-0363c376ace0','4b802c51-2823-49f4-9ec9-0363c376ace0','10-oct-2023','2023-10-10 23:11:32','2023-10-10 23:11:32',NULL),
('51c57a77-ee88-11ed-8002-d89d6776f970','ac496de0-bdc8-11ed-afa1-0242ac120002','b3b1f1bb-2c6a-4e8e-a730-6e7e52de6c4e','http://10.210.0.27:8081/documentos/d8aeb001-e864-4d72-9050-ec90f1554df9','d8aeb001-e864-4d72-9050-ec90f1554df9','d8aeb001-e864-4d72-9050-ec90f1554df9','2023-05-09','2023-05-09 16:41:51','2023-05-09 17:26:35','2023-05-09 17:26:35'),
('7dd809b2-630a-11ee-a933-236cb4402701','ac4967f0-bdc8-11ed-afa1-0242ac120002','fb37feaa-efe8-40c3-b85d-80ca8ab66cf1','http://10.210.26.26:8081/documentos/c565a3b3-ae40-4186-8b1a-053f34a21665','c565a3b3-ae40-4186-8b1a-053f34a21665','c565a3b3-ae40-4186-8b1a-053f34a21665','4-oct-2023','2023-10-04 22:08:27','2023-10-04 22:08:27',NULL),
('91c43b27-630c-11ee-a933-236cb4402701','ac4967f0-bdc8-11ed-afa1-0242ac120002','a9f6bfc2-5d00-4ca2-80f5-4f7a9f8a7e39','http://10.210.26.26:8081/documentos/afad6557-fe6c-490b-aa6a-55cf0e3e9f7c','afad6557-fe6c-490b-aa6a-55cf0e3e9f7c','afad6557-fe6c-490b-aa6a-55cf0e3e9f7c','4-oct-2023','2023-10-04 22:23:20','2023-10-04 22:23:20',NULL),
('9a49851b-67c6-11ee-a933-236cb4402701','ac4967f0-bdc8-11ed-afa1-0242ac120002','b3b1f1bb-2c6a-4e8e-a730-6e7e52de6c4e','http://10.210.26.26:8081/documentos/970e0acc-8571-4b0b-a44d-b960bd49bdde','970e0acc-8571-4b0b-a44d-b960bd49bdde','970e0acc-8571-4b0b-a44d-b960bd49bdde','10-oct-2023','2023-10-10 22:45:18','2023-10-10 22:45:18',NULL),
('a0dff006-f10d-11ed-8002-d89d6776f970','ac4967f0-bdc8-11ed-afa1-0242ac120002','b3b1f1bb-2c6a-4e8e-a730-6e7e52de6c4e','http://10.210.0.27:8081/documentos/e167e7ea-0c2e-4fe2-b163-0335b3ce5a40','e167e7ea-0c2e-4fe2-b163-0335b3ce5a40','e167e7ea-0c2e-4fe2-b163-0335b3ce5a40','2023-05-12','2023-05-12 21:41:12','2023-05-12 21:41:12',NULL),
('ac547a65-bb98-11ee-8dee-d89d6776f970','ac4967f0-bdc8-11ed-afa1-0242ac120002','b3b1f1bb-2c6a-4e8e-a730-6e7e52de6c4e','http://10.210.26.26:8081/documentos/77a3dcbd-7b8f-4145-bab5-4761f4122e43','77a3dcbd-7b8f-4145-bab5-4761f4122e43','77a3dcbd-7b8f-4145-bab5-4761f4122e43','25-ene-2024','2024-01-25 15:48:43','2024-01-25 17:10:50','2024-01-25 17:10:50'),
('b9e39786-ee92-11ed-8002-d89d6776f970','ac4967f0-bdc8-11ed-afa1-0242ac120002','b3b1f1bb-2c6a-4e8e-a730-6e7e52de6c4e','http://10.210.0.27:8081/documentos/e9882c84-5f59-4a3f-ab04-c63577c2a557','e9882c84-5f59-4a3f-ab04-c63577c2a557','e9882c84-5f59-4a3f-ab04-c63577c2a557','2023-05-09','2023-05-09 17:56:20','2023-05-09 17:56:20',NULL),
('bbd1fca8-eab2-11ed-8002-d89d6776f970','ac4967f0-bdc8-11ed-afa1-0242ac120002','b3b1f1bb-2c6a-4e8e-a730-6e7e52de6c4e','http://10.210.0.27:8081/documentos/0ac09aa2-3c38-4892-9a66-f9be75a9a3dc','0ac09aa2-3c38-4892-9a66-f9be75a9a3dc','0ac09aa2-3c38-4892-9a66-f9be75a9a3dc','2023-05-04','2023-05-04 19:35:18','2023-05-09 16:38:32','2023-05-09 16:38:32'),
('bc472964-eebd-11ed-8002-d89d6776f970','ac4967f0-bdc8-11ed-afa1-0242ac120002','b3b1f1bb-2c6a-4e8e-a730-6e7e52de6c4e','http://10.210.0.27:8081/documentos/1151968f-a90c-4733-91b0-414beada0915','1151968f-a90c-4733-91b0-414beada0915','1151968f-a90c-4733-91b0-414beada0915','2023-05-09','2023-05-09 23:04:13','2023-05-09 23:04:13',NULL);
/*!40000 ALTER TABLE `PathDocumentos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Recibidos`
--

DROP TABLE IF EXISTS `Recibidos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Recibidos` (
  `Id` char(36) NOT NULL,
  `IdEstatusBandeja` char(36) DEFAULT NULL,
  `IdUsuario` char(36) DEFAULT NULL,
  `IdPathDoc` char(36) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Recibidos`
--

LOCK TABLES `Recibidos` WRITE;
/*!40000 ALTER TABLE `Recibidos` DISABLE KEYS */;
INSERT INTO `Recibidos` VALUES
('027115d1-66d1-41ac-b98f-34f59d4bd2fb','ac49701a-bdc8-11ed-afa1-0242ac120002','30adc962-7109-11ed-a880-040300000000','358fbce4-eebe-11ed-8002-d89d6776f970','2023-05-09 23:26:54','2023-05-09 23:26:54'),
('03b0d79b-f61f-41bb-af79-3363738c19db',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-03-17 22:48:05','2023-03-17 22:48:05'),
('05a6f99a-1b65-4266-8364-732aebed0295',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-03-17 22:48:04','2023-03-17 22:48:04'),
('05f2ec80-bc25-4013-a0d9-94cb106f4704','ac49701a-bdc8-11ed-afa1-0242ac120002','d8483c80-c9b4-11ed-afa1-0242ac120002','a9062320-d30c-11ed-8002-d89d6776f970','2023-04-04 17:18:53','2023-04-04 17:18:53'),
('06e90aec-e090-487b-8d60-0995ac4ae2ee','ac49701a-bdc8-11ed-afa1-0242ac120002','1d11dce0-bfa1-11ed-afa1-0242ac120002','76b04fe4-bdd3-11ed-b789-2c4138b7dab1','2023-03-17 16:00:09','2023-03-17 16:00:09'),
('07d0bf36-73b2-4827-bd74-a9dad238f599',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-03-29 19:27:47','2023-03-29 19:27:47'),
('09b2ca1d-5cac-4f80-9d51-39d7ec159cf1','ac49701a-bdc8-11ed-afa1-0242ac120002','54cbef5c-c1ce-11ed-afa1-0242ac120002','76b04fe4-bdd3-11ed-b789-2c4138b7dab1','2023-03-17 16:07:03','2023-03-17 16:07:03'),
('0a45186f-2284-4956-b4d2-9db4056c3e68',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-04-04 17:58:05','2023-04-04 17:58:05'),
('0ada5f2a-5533-4e3f-b4b1-f5af02a286e6',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-03-17 22:49:54','2023-03-17 22:49:54'),
('0ea06d45-73b4-48c6-bfb7-c3a0f1027e34','ac49701a-bdc8-11ed-afa1-0242ac120002','d8483c80-c9b4-11ed-afa1-0242ac120002','f08ed1ec-d269-11ed-8002-d89d6776f970','2023-04-03 21:55:38','2023-04-03 21:55:38'),
('0fef598c-626e-4a9b-bd3a-e40cc711aa63','ac49701a-bdc8-11ed-afa1-0242ac120002','d8483c80-c9b4-11ed-afa1-0242ac120002','11f0f254-eaae-11ed-8002-d89d6776f970','2023-05-04 19:02:17','2023-05-04 19:02:17'),
('10b7a316-a344-448c-9341-e84313c55e3a',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-03-23 19:45:29','2023-03-23 19:45:29'),
('11646305-bd3e-466f-b03c-8415c87c7914',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-03-30 19:49:15','2023-03-30 19:49:15'),
('156dfdb3-dc44-4083-887b-75e74f700a3f',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-10-04 22:01:00','2023-10-04 22:01:00'),
('16188102-d6b6-49d0-9dbc-bebeeb220066',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-04-03 21:53:13','2023-04-03 21:53:13'),
('18b48f08-9419-49ec-a1a7-cd015bf0e2fd','ac49701a-bdc8-11ed-afa1-0242ac120002','30adc962-7109-11ed-a880-040300000000','358fbce4-eebe-11ed-8002-d89d6776f970','2023-05-09 23:26:54','2023-05-09 23:26:54'),
('1a5b111a-b0b1-4884-87e3-9f3fa0d6db28',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-03-17 22:49:53','2023-03-17 22:49:53'),
('1d591819-7b2e-45b0-83fa-760c90241818','ac49701a-bdc8-11ed-afa1-0242ac120002','1d11dce0-bfa1-11ed-afa1-0242ac120002','76b04fe4-bdd3-11ed-b789-2c4138b7dab1','2023-03-17 16:07:03','2023-03-17 16:07:03'),
('1e4b62e5-7afc-4db0-9ee6-da9e8ad45fc4',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-03-17 15:43:03','2023-03-17 15:43:03'),
('2011e016-ff4d-4ea3-a254-fbdadd1b4999',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-05-09 17:56:19','2023-05-09 17:56:19'),
('20ba4e1c-8632-47fe-9054-5c2b605b4cfa',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-05-04 19:15:54','2023-05-04 19:15:54'),
('21c0bdfe-9a4f-41d2-ad93-189d65e5ed90',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-10-10 23:11:29','2023-10-10 23:11:29'),
('21db87d2-f90d-4233-927e-8b73e02f9eee',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-04-04 16:16:44','2023-04-04 16:16:44'),
('225d9f15-adea-4034-8941-1d00c59da069','ac49701a-bdc8-11ed-afa1-0242ac120002','1d11dce0-bfa1-11ed-afa1-0242ac120002','76b04fe4-bdd3-11ed-b789-2c4138b7dab1','2023-03-17 16:10:16','2023-03-17 16:10:16'),
('22cca988-a604-4d52-8a23-df36360382e5',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-10-04 22:00:35','2023-10-04 22:00:35'),
('2479efa0-2bf0-4cde-8ea8-5fd65693a3b3',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-10-10 23:11:32','2023-10-10 23:11:32'),
('25a0c4af-7af5-456c-9813-45784b894825',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-05-09 23:07:36','2023-05-09 23:07:36'),
('291dbdab-bf34-489e-8f57-41516d484014',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2024-01-25 15:48:41','2024-01-25 15:48:41'),
('2b972115-93e6-4e06-be6a-51010f05da31',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-03-29 19:38:02','2023-03-29 19:38:02'),
('2bd87f78-85ae-4eea-a812-f82f6eee3b8c','ac49701a-bdc8-11ed-afa1-0242ac120002','54cbec0a-c1ce-11ed-afa1-0242ac120002','76b04fe4-bdd3-11ed-b789-2c4138b7dab1','2023-03-17 16:15:33','2023-03-17 16:15:33'),
('2c083dd9-b3f3-4818-bc7e-31f69801a62c','ac49701a-bdc8-11ed-afa1-0242ac120002','d8483c80-c9b4-11ed-afa1-0242ac120002','61e4a9eb-d310-11ed-8002-d89d6776f970','2023-04-04 17:45:03','2023-04-04 17:45:03'),
('2cc18cb5-5dac-4c54-9c34-2807fa782fe0',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-04-04 17:58:03','2023-04-04 17:58:03'),
('2cdcbb9b-ad46-4fc1-95d3-1d59d4f74e46','ac49701a-bdc8-11ed-afa1-0242ac120002','d8483c80-c9b4-11ed-afa1-0242ac120002','1786bd05-d304-11ed-8002-d89d6776f970','2023-04-04 16:17:21','2023-04-04 16:17:21'),
('2e06beb5-960f-4761-baf9-cc2a3bd031d2',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-03-29 19:27:46','2023-03-29 19:27:46'),
('2fd437e4-0772-4ae6-8f39-ffd1c05c8adf','ac49701a-bdc8-11ed-afa1-0242ac120002','d8483c80-c9b4-11ed-afa1-0242ac120002','f66cc3e4-cf33-11ed-8002-d89d6776f970','2023-03-30 20:59:29','2023-03-30 20:59:29'),
('30ae4bc7-ef15-4b12-9e06-0793d249c65e',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-05-09 23:07:35','2023-05-09 23:07:35'),
('3242b834-4919-4e18-be89-e99d18d977b8',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-05-04 19:01:55','2023-05-04 19:01:55'),
('33e7fac6-88c4-4a25-8c7c-4632613de62b',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-04-04 17:44:41','2023-04-04 17:44:41'),
('359a9de6-c9b7-459d-8861-f9ab2ab6f1e5',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-04-04 17:50:29','2023-04-04 17:50:29'),
('37477551-3e67-43f6-a583-bce85a7f5bb2','ac49701a-bdc8-11ed-afa1-0242ac120002','d8483c80-c9b4-11ed-afa1-0242ac120002','400b0349-d312-11ed-8002-d89d6776f970','2023-04-04 17:58:55','2023-04-04 17:58:55'),
('3a4745cc-d5be-4d03-a5c8-ffca82620889','ac49701a-bdc8-11ed-afa1-0242ac120002','54cbef5c-c1ce-11ed-afa1-0242ac120002','76b04fe4-bdd3-11ed-b789-2c4138b7dab1','2023-03-17 16:21:47','2023-03-17 16:21:47'),
('3acc8842-51ca-4366-ae56-a39424a4659a','ac49701a-bdc8-11ed-afa1-0242ac120002','209d29f5-71dc-11ed-a880-040300000000','400b0349-d312-11ed-8002-d89d6776f970','2023-04-04 17:58:55','2023-04-04 17:58:55'),
('3ad81651-53c7-44f1-ae28-6556e980c588',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-05-04 19:09:33','2023-05-04 19:09:33'),
('3bf4120e-ce2f-4ce2-9c58-4b2f56e43a64',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-04-05 15:42:57','2023-04-05 15:42:57'),
('3dda6211-0473-4830-9f5c-bd3277b2e4bc',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-04-05 16:30:51','2023-04-05 16:30:51'),
('3e9b92e9-ed5c-4fa6-9a6a-05a77a8455dc',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-03-17 19:00:24','2023-03-17 19:00:24'),
('424eb095-842a-4b07-b4de-d55e3e50ee1c',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-04-04 17:18:04','2023-04-04 17:18:04'),
('43e62945-27df-4b86-82ea-7a247073064d',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-04-05 15:42:55','2023-04-05 15:42:55'),
('4537ce20-be55-47fd-9f37-ff7be15c0835','ac49701a-bdc8-11ed-afa1-0242ac120002','d8483c80-c9b4-11ed-afa1-0242ac120002','0a419dd8-d30f-11ed-8002-d89d6776f970','2023-04-04 17:35:38','2023-04-04 17:35:38'),
('45947a0b-9700-4ac5-b4c9-97e15673c56f',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-04-05 15:54:17','2023-04-05 15:54:17'),
('46ccfb6d-7278-46ba-a94e-f74501016e3e',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-03-29 19:38:01','2023-03-29 19:38:01'),
('48800324-8e05-4edd-aae5-a28a3f3b32b8','ac49701a-bdc8-11ed-afa1-0242ac120002','d8483c80-c9b4-11ed-afa1-0242ac120002','141fa7e7-d3da-11ed-8002-d89d6776f970','2023-04-05 17:49:57','2023-04-05 17:49:57'),
('4a0f11c1-9a5e-45f5-9b89-6f138b6dedcf',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-04-05 17:55:10','2023-04-05 17:55:10'),
('4bb91321-f445-4b30-b7b4-69999c466b06',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-10-04 21:58:31','2023-10-04 21:58:31'),
('516122ee-bca2-4cfd-9a01-bc1ba27be66a',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-10-04 22:08:26','2023-10-04 22:08:26'),
('53f961d8-95e2-4513-be76-80f4ecb24565',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-10-10 22:49:09','2023-10-10 22:49:09'),
('552cbebd-973b-4747-a371-9ca3a774a044','ac49701a-bdc8-11ed-afa1-0242ac120002','09e620ae-b87d-11ed-8002-d89d6776f970','cd5549dc-ce67-11ed-8002-d89d6776f970','2023-04-04 17:41:47','2023-04-04 17:41:47'),
('5546486c-7fda-40b7-9201-01b62579e49d','ac49701a-bdc8-11ed-afa1-0242ac120002','1d11dce0-bfa1-11ed-afa1-0242ac120002','76b04fe4-bdd3-11ed-b789-2c4138b7dab1','2023-03-17 16:15:33','2023-03-17 16:15:33'),
('55bf4240-933f-4b58-84d8-1301d6818e7e','ac49701a-bdc8-11ed-afa1-0242ac120002','30adc962-7109-11ed-a880-040300000000','51c57a77-ee88-11ed-8002-d89d6776f970','2023-05-09 16:42:26','2023-05-09 16:42:26'),
('5663252a-c18d-4883-a142-b626e2287fee',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-04-04 17:35:06','2023-04-04 17:35:06'),
('59c929a3-ac27-47cd-afec-d68240464eb9','ac49701a-bdc8-11ed-afa1-0242ac120002','a77a303c-3a98-11ed-a261-0242ac120002','f9d3a2a2-c4f5-11ed-b789-2c4138b7dab1','2023-03-17 19:46:25','2023-03-17 19:46:25'),
('5a0e2deb-d312-451f-9508-71c2e1b3cabb','ac49701a-bdc8-11ed-afa1-0242ac120002','54cbef5c-c1ce-11ed-afa1-0242ac120002','76b04fe4-bdd3-11ed-b789-2c4138b7dab1','2023-03-17 16:15:33','2023-03-17 16:15:33'),
('5a6de77f-dfbe-4406-b1f1-6ebd267cc8ad',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-10-04 21:52:07','2023-10-04 21:52:07'),
('5aa83692-969a-4a32-939c-40cb0d44cfbe',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-05-09 17:56:20','2023-05-09 17:56:20'),
('5b6181ab-33cb-47c3-8116-f4302f716ef7',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-04-03 21:53:15','2023-04-03 21:53:15'),
('5b8f51a9-5c99-481d-90f8-56d59f07a556','ac49701a-bdc8-11ed-afa1-0242ac120002','d8483c80-c9b4-11ed-afa1-0242ac120002','3a38998b-d3cf-11ed-8002-d89d6776f970','2023-04-05 16:31:08','2023-04-05 16:31:08'),
('5c66d76d-fb52-4892-92ab-0fd3c1f8e866','ac49701a-bdc8-11ed-afa1-0242ac120002','54cbec0a-c1ce-11ed-afa1-0242ac120002','76b04fe4-bdd3-11ed-b789-2c4138b7dab1','2023-03-17 16:07:03','2023-03-17 16:07:03'),
('5ce08fc5-52cb-4348-ad66-33af75442b62',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-05-09 16:41:49','2023-05-09 16:41:49'),
('60e817dd-d6b0-4987-96c5-18086e451231','ac49701a-bdc8-11ed-afa1-0242ac120002','54cbef5c-c1ce-11ed-afa1-0242ac120002','76b04fe4-bdd3-11ed-b789-2c4138b7dab1','2023-03-17 16:16:23','2023-03-17 16:16:23'),
('62770dd1-98ae-4f89-a758-29213a00b33f','ac49701a-bdc8-11ed-afa1-0242ac120002','undefined','0893105b-c516-11ed-b789-2c4138b7dab1','2023-03-17 22:58:22','2023-03-17 22:58:22'),
('63c3a7ae-c1d1-478c-8d3b-1c382d316ce8','ac49701a-bdc8-11ed-afa1-0242ac120002','54cbec0a-c1ce-11ed-afa1-0242ac120002','76b04fe4-bdd3-11ed-b789-2c4138b7dab1','2023-03-17 16:25:39','2023-03-17 16:25:39'),
('65697e40-52c0-4d73-8600-6ea8c5f38e7e','ac49701a-bdc8-11ed-afa1-0242ac120002','0c130706-7266-11ed-a880-040300000000','8b0ab7bb-d311-11ed-8002-d89d6776f970','2023-04-04 17:54:07','2023-04-04 17:54:07'),
('657714eb-3913-4a79-b1e0-30fee0cc0cb8',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-03-17 19:00:25','2023-03-17 19:00:25'),
('66c4daa3-5cad-4320-bd55-63c2d432aa5a','ac49701a-bdc8-11ed-afa1-0242ac120002','09e620ae-b87d-11ed-8002-d89d6776f970','61e4a9eb-d310-11ed-8002-d89d6776f970','2023-04-04 17:45:03','2023-04-04 17:45:03'),
('68cb5ffb-68e9-4198-a106-b46894dfb375',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-10-04 22:08:27','2023-10-04 22:08:27'),
('691456cc-9d89-4246-ad61-df927bd54560',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2024-01-25 15:48:43','2024-01-25 15:48:43'),
('6bf8143b-ed7d-4c6f-a967-465dc075131a','ac49701a-bdc8-11ed-afa1-0242ac120002','a6860b44-3087-11ed-aed0-040300000000','67d3013f-c4da-11ed-b789-2c4138b7dab1','2023-03-17 18:28:21','2023-03-17 18:28:21'),
('6d59d869-dc3e-4027-9cdd-3a20cf22f2d1',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-05-04 19:01:53','2023-05-04 19:01:53'),
('6e1138fe-2a9d-4dd7-a6d4-b345be9e85f1',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-05-04 19:35:18','2023-05-04 19:35:18'),
('6f3b3eaf-ee2b-41dd-9a51-aa4d89d79e1b',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-05-09 23:04:13','2023-05-09 23:04:13'),
('765675be-565b-4b09-bf91-270fcbe60613',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-03-17 18:35:19','2023-03-17 18:35:19'),
('78dee1e5-aa6d-498c-8b95-5b68e80a39cc','ac49701a-bdc8-11ed-afa1-0242ac120002','209d29f5-71dc-11ed-a880-040300000000','8b0ab7bb-d311-11ed-8002-d89d6776f970','2023-04-04 17:54:07','2023-04-04 17:54:07'),
('78e17a08-c52c-4697-8b97-fa49aaa60d0b','ac49701a-bdc8-11ed-afa1-0242ac120002','d8483c80-c9b4-11ed-afa1-0242ac120002','f66cc3e4-cf33-11ed-8002-d89d6776f970','2023-03-30 20:59:29','2023-03-30 20:59:29'),
('7a979f51-ccd1-42cd-92d7-a9307e40bc6e','ac49701a-bdc8-11ed-afa1-0242ac120002','2fad75f3-b79f-11ed-8002-d89d6776f970','400b0349-d312-11ed-8002-d89d6776f970','2023-04-04 17:58:55','2023-04-04 17:58:55'),
('7c06a0e5-9ae4-4b54-bdfa-94f3e77537be','ac49701a-bdc8-11ed-afa1-0242ac120002','1d11dce0-bfa1-11ed-afa1-0242ac120002','76b04fe4-bdd3-11ed-b789-2c4138b7dab1','2023-03-17 16:25:39','2023-03-17 16:25:39'),
('7cc651d1-5360-46d6-8c57-141328aedad5',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-04-05 17:48:30','2023-04-05 17:48:30'),
('7d76bd31-bec3-4609-98b7-54be1f8ca04d',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-10-04 22:05:20','2023-10-04 22:05:20'),
('8bb406b4-7c0e-42a3-8aa9-aa13d2db7d6c','ac49701a-bdc8-11ed-afa1-0242ac120002','d8483c80-c9b4-11ed-afa1-0242ac120002','3bf9286d-ce69-11ed-8002-d89d6776f970','2023-03-30 21:14:35','2023-03-30 21:14:35'),
('8d185ace-b70d-48fd-8c1c-8866a9dd85ca','ac49701a-bdc8-11ed-afa1-0242ac120002','09e620ae-b87d-11ed-8002-d89d6776f970','8b0ab7bb-d311-11ed-8002-d89d6776f970','2023-04-04 17:54:07','2023-04-04 17:54:07'),
('8e7200ed-2329-410c-abf4-54706439f954',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-10-04 22:23:20','2023-10-04 22:23:20'),
('8fe22d6e-1786-49b3-984d-4319fd1c46d6',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-03-23 19:50:17','2023-03-23 19:50:17'),
('950c6405-29ab-407e-973a-ffeb18ba426c','ac49701a-bdc8-11ed-afa1-0242ac120002','09e620ae-b87d-11ed-8002-d89d6776f970','0a419dd8-d30f-11ed-8002-d89d6776f970','2023-04-04 17:35:38','2023-04-04 17:35:38'),
('96ab683d-eb43-4b49-9d5d-df30209208a6','ac49701a-bdc8-11ed-afa1-0242ac120002','a6860b44-3087-11ed-aed0-040300000000','c7cfe258-c515-11ed-b789-2c4138b7dab1','2023-03-21 18:23:00','2023-03-21 18:23:00'),
('97db935e-ed3d-4a99-98bc-c6ff2bd98a5e','ac49701a-bdc8-11ed-afa1-0242ac120002','54cbec0a-c1ce-11ed-afa1-0242ac120002','76b04fe4-bdd3-11ed-b789-2c4138b7dab1','2023-03-17 16:21:47','2023-03-17 16:21:47'),
('9b5ae784-3ad7-4a08-8e58-cbb4989fb0f9',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-10-04 22:01:24','2023-10-04 22:01:24'),
('9f625162-37e5-40bd-b0d6-c191bb223b5a','ac49701a-bdc8-11ed-afa1-0242ac120002','0c130706-7266-11ed-a880-040300000000','400b0349-d312-11ed-8002-d89d6776f970','2023-04-04 17:58:55','2023-04-04 17:58:55'),
('a1492def-2f05-40cc-a4f3-263b5267c234','ac49701a-bdc8-11ed-afa1-0242ac120002','1d11dce0-bfa1-11ed-afa1-0242ac120002','76b04fe4-bdd3-11ed-b789-2c4138b7dab1','2023-03-17 16:21:47','2023-03-17 16:21:47'),
('a9463093-98c1-4956-8d8a-461477bc06a0',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-04-04 17:35:04','2023-04-04 17:35:04'),
('aa9de738-19c0-4962-b07a-c7c4cfe895c1',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-03-17 22:40:45','2023-03-17 22:40:45'),
('aab495a6-f3ce-4b3b-85d2-8a41f2722cd8','ac49701a-bdc8-11ed-afa1-0242ac120002','54cbef5c-c1ce-11ed-afa1-0242ac120002','76b04fe4-bdd3-11ed-b789-2c4138b7dab1','2023-03-17 16:10:16','2023-03-17 16:10:16'),
('aada5ac5-b4b9-47e3-ab23-2355eff00e6e',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-10-04 21:56:42','2023-10-04 21:56:42'),
('ab6f9da4-fc0b-48df-b7cb-ca995b7764d0',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-10-04 21:51:17','2023-10-04 21:51:17'),
('acb79b58-4944-4cb5-8583-a5bedb82e084','ac49701a-bdc8-11ed-afa1-0242ac120002','d8483c80-c9b4-11ed-afa1-0242ac120002','1eed38e5-d3ca-11ed-8002-d89d6776f970','2023-04-05 15:56:09','2023-04-05 15:56:09'),
('acf8b782-ca68-4d82-a81e-a942bbffc9e9',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-04-04 17:53:01','2023-04-04 17:53:01'),
('af67697c-c225-4e61-bc5d-fffff31f9029','ac49701a-bdc8-11ed-afa1-0242ac120002','d8483c80-c9b4-11ed-afa1-0242ac120002','307608e7-d311-11ed-8002-d89d6776f970','2023-04-04 17:51:00','2023-04-04 17:51:00'),
('b43862c7-200f-4fa7-82eb-98005d3f8d7e',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-10-04 22:23:18','2023-10-04 22:23:18'),
('b712f489-1ac9-4050-aaea-6359a288f58c',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-04-04 17:50:27','2023-04-04 17:50:27'),
('b71fea85-51bf-4dc5-b223-35bb86fba1c5',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-10-10 22:45:18','2023-10-10 22:45:18'),
('b7511830-6b64-4278-8a00-47978f6b40a0',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-04-04 16:16:42','2023-04-04 16:16:42'),
('b901f12d-3054-4cc1-885b-66de20716f6c','ac49701a-bdc8-11ed-afa1-0242ac120002','a77a303c-3a98-11ed-a261-0242ac120002','7820f112-c4f2-11ed-b789-2c4138b7dab1','2023-03-17 23:01:43','2023-03-17 23:01:43'),
('b9fe7874-a419-4bf3-b5b1-5a23d3c1c0b9',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-04-05 17:55:08','2023-04-05 17:55:08'),
('ba97daed-ce80-403b-867f-62172fd3de5e',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-04-05 17:48:31','2023-04-05 17:48:31'),
('bb1c4867-9845-4612-8449-895db11281c3',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-03-17 15:43:04','2023-03-17 15:43:04'),
('be703590-4c17-4deb-b766-f0a99d0886d6',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-10-10 22:49:11','2023-10-10 22:49:11'),
('bf41e116-cb22-489e-9c35-17b90869887e',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-05-09 16:41:51','2023-05-09 16:41:51'),
('bf7a6f0a-d79c-435f-b21c-05b59fb7968c','ac4971fa-bdc8-11ed-afa1-0242ac120002','d8483c80-c9b4-11ed-afa1-0242ac120002','01ca9985-d3db-11ed-8002-d89d6776f970','2023-04-05 17:55:27','2023-04-14 19:03:13'),
('c02c63fb-9d3b-4b27-8879-e3d524cdf077',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-03-23 17:58:33','2023-03-23 17:58:33'),
('c0a53b1a-5529-4df9-8ecf-6f5281ddb398','ac49701a-bdc8-11ed-afa1-0242ac120002','09e620ae-b87d-11ed-8002-d89d6776f970','400b0349-d312-11ed-8002-d89d6776f970','2023-04-04 17:58:55','2023-04-04 17:58:55'),
('c0a69569-37d6-49f2-b996-8c2d25f0120c','ac49701a-bdc8-11ed-afa1-0242ac120002','d8483c80-c9b4-11ed-afa1-0242ac120002','8b0ab7bb-d311-11ed-8002-d89d6776f970','2023-04-04 17:54:07','2023-04-04 17:54:07'),
('c336de82-8cad-43f8-80fb-bc1f09e47790',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-03-17 22:40:47','2023-03-17 22:40:47'),
('c4863b9e-c623-47d8-80c2-4a3373825e63',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-04-05 16:30:49','2023-04-05 16:30:49'),
('c5221cc6-87b0-4c9a-840f-2e8b5b786f90','ac49701a-bdc8-11ed-afa1-0242ac120002','0c130706-7266-11ed-a880-040300000000','307608e7-d311-11ed-8002-d89d6776f970','2023-04-04 17:51:00','2023-04-04 17:51:00'),
('c6542e93-f01b-46a3-9134-5068997f9798',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-03-17 18:35:18','2023-03-17 18:35:18'),
('c7539e30-0eda-4ee1-803e-32151974b554',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-05-09 23:04:11','2023-05-09 23:04:11'),
('c778cca6-8d29-48d4-ad9c-be60c9a5c576',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-05-04 19:35:16','2023-05-04 19:35:16'),
('c8da3cab-4311-4d63-b1b4-dd9e4b863be0',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-10-04 21:54:43','2023-10-04 21:54:43'),
('cb16d021-8376-4ab7-b278-1ac1ea79f70e','ac49701a-bdc8-11ed-afa1-0242ac120002','5dbda069-b6ca-11ed-9bd4-2c4138b7dab1','67d3013f-c4da-11ed-b789-2c4138b7dab1','2023-03-17 18:28:21','2023-03-17 18:28:21'),
('cb830f5e-199b-4216-9b95-ea517c9d2960','ac49701a-bdc8-11ed-afa1-0242ac120002','a77a303c-3a98-11ed-a261-0242ac120002','0893105b-c516-11ed-b789-2c4138b7dab1','2023-03-17 22:58:22','2023-03-17 22:58:22'),
('ccc32e7c-4c2e-43e6-9cdc-40a0cd48986c','ac49701a-bdc8-11ed-afa1-0242ac120002','d8483c80-c9b4-11ed-afa1-0242ac120002','891d01fe-d3c8-11ed-8002-d89d6776f970','2023-04-05 15:43:42','2023-04-05 15:43:42'),
('ce7d9473-641e-42ba-ac74-89c7f3016018',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-10-04 22:05:17','2023-10-04 22:05:17'),
('d16de4ce-a3ec-441d-9056-7784cc1a639b',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-04-05 15:54:16','2023-04-05 15:54:16'),
('d50edc82-ac68-461b-8399-c46a10b5863a',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-10-10 22:45:16','2023-10-10 22:45:16'),
('d71f6d87-0bb1-452b-888f-7212556699bb','ac49701a-bdc8-11ed-afa1-0242ac120002','1d11dce0-bfa1-11ed-afa1-0242ac120002','76b04fe4-bdd3-11ed-b789-2c4138b7dab1','2023-03-17 16:16:23','2023-03-17 16:16:23'),
('d80d4581-cfd8-4dc6-9978-804729f853f4','ac49701a-bdc8-11ed-afa1-0242ac120002','d8483c80-c9b4-11ed-afa1-0242ac120002','cd5549dc-ce67-11ed-8002-d89d6776f970','2023-04-04 17:41:47','2023-04-04 17:41:47'),
('d81be053-ac7b-4746-8a51-7c13da747402','ac49701a-bdc8-11ed-afa1-0242ac120002','5dbda069-b6ca-11ed-9bd4-2c4138b7dab1','0893105b-c516-11ed-b789-2c4138b7dab1','2023-03-17 22:58:22','2023-03-17 22:58:22'),
('dbe78798-d136-48e5-af4e-753eede00a0e',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-04-04 17:18:02','2023-04-04 17:18:02'),
('dccca8dc-ad1d-4d25-a077-7a3abef0e2a4',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-05-04 19:15:39','2023-05-04 19:15:39'),
('de5fa24b-04b7-4517-8cb8-51b2e12518f8',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-05-12 21:41:12','2023-05-12 21:41:12'),
('df50bbf3-c85e-4408-aa8f-eb60006d4622',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-03-30 16:17:12','2023-03-30 16:17:12'),
('e20d9b33-4654-47e4-83c3-c2fc19b472c2',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-03-30 19:49:13','2023-03-30 19:49:13'),
('e29c7fe9-c93f-4b48-b71b-263802820d2e','ac49701a-bdc8-11ed-afa1-0242ac120002','5dbda069-b6ca-11ed-9bd4-2c4138b7dab1','f9d3a2a2-c4f5-11ed-b789-2c4138b7dab1','2023-03-17 19:46:25','2023-03-17 19:46:25'),
('e3d69def-5735-4a47-960c-f480c54a58bc',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-03-29 19:21:07','2023-03-29 19:21:07'),
('e7d7d03a-d3e1-4470-86b8-909a3324d5de','ac49701a-bdc8-11ed-afa1-0242ac120002','54cbec0a-c1ce-11ed-afa1-0242ac120002','76b04fe4-bdd3-11ed-b789-2c4138b7dab1','2023-03-17 16:00:09','2023-03-17 16:00:09'),
('e8d6703a-948d-42c9-b77e-cdeb0f4dc897',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-05-12 21:41:10','2023-05-12 21:41:10'),
('ea2766f4-4736-48a3-87d2-7a102057bd2b','ac49701a-bdc8-11ed-afa1-0242ac120002','54cbef5c-c1ce-11ed-afa1-0242ac120002','76b04fe4-bdd3-11ed-b789-2c4138b7dab1','2023-03-17 16:25:39','2023-03-17 16:25:39'),
('ed567d44-c50d-4d70-bbf6-b797c1d7ae1b',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-10-04 21:59:09','2023-10-04 21:59:09'),
('efa50deb-e951-4a07-9f20-29099a6c0443',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-04-04 17:44:42','2023-04-04 17:44:42'),
('f24c20e2-3e54-49a2-b202-edada2d67449','ac49701a-bdc8-11ed-afa1-0242ac120002','54cbec0a-c1ce-11ed-afa1-0242ac120002','76b04fe4-bdd3-11ed-b789-2c4138b7dab1','2023-03-17 16:10:16','2023-03-17 16:10:16'),
('f7c186b4-da36-4507-9003-6745fe0a1753',NULL,'b0ef2cfa-bea8-11ed-afa1-0242ac120002','b0ef3088-bea8-11ed-afa1-0242ac120002','2023-04-04 17:52:59','2023-04-04 17:52:59'),
('f9e23c14-79ed-4b1b-80e6-943ec863ec0c','ac49701a-bdc8-11ed-afa1-0242ac120002','undefined','67d3013f-c4da-11ed-b789-2c4138b7dab1','2023-03-17 18:28:21','2023-03-17 18:28:21'),
('fbf24e7a-9aa5-492a-93a3-202e3098a811','ac49701a-bdc8-11ed-afa1-0242ac120002','54cbef5c-c1ce-11ed-afa1-0242ac120002','76b04fe4-bdd3-11ed-b789-2c4138b7dab1','2023-03-17 16:00:09','2023-03-17 16:00:09'),
('fdaefd43-91f6-4f62-9318-f660c9737877','ac49701a-bdc8-11ed-afa1-0242ac120002','54cbec0a-c1ce-11ed-afa1-0242ac120002','76b04fe4-bdd3-11ed-b789-2c4138b7dab1','2023-03-17 16:16:23','2023-03-17 16:16:23');
/*!40000 ALTER TABLE `Recibidos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TipoDocumento`
--

DROP TABLE IF EXISTS `TipoDocumento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TipoDocumento` (
  `Id` char(36) NOT NULL,
  `Nombre` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TipoDocumento`
--

LOCK TABLES `TipoDocumento` WRITE;
/*!40000 ALTER TABLE `TipoDocumento` DISABLE KEYS */;
INSERT INTO `TipoDocumento` VALUES
('22f74f1c-d5a3-4744-8888-85923a1f56af','Oficio','2023-02-16 17:08:20','2023-02-16 17:08:20',0),
('3c3d8468-3f6f-4486-8f8f-0a45952e04a6','Acuse','2023-02-23 22:46:38','2023-02-23 22:46:38',0),
('4cf07966-aef4-45a9-98c4-c91cb6601136','Acuse','2023-04-04 17:24:39','2023-04-04 17:24:39',0),
('54608ef8-3722-4f01-9943-21d319863f87','Oficio','2023-02-21 19:53:44','2023-02-21 19:53:44',0),
('7b372135-9921-488b-a3a6-bb3a5552ca24','Oficio','2023-02-21 22:00:33','2023-02-22 16:26:14',0),
('86a5d20b-806a-4418-9a18-6b7753011a6b','Oficio','2023-03-13 15:40:41','2023-03-13 15:40:41',0),
('a9f6bfc2-5d00-4ca2-80f5-4f7a9f8a7e39','Oficio','2023-10-04 22:15:26','2023-10-04 22:15:26',0),
('b3b1f1bb-2c6a-4e8e-a730-6e7e52de6c4e','Oficio','2023-04-04 17:24:55','2023-04-19 20:45:53',0),
('c7d81908-1075-4034-91f2-f8e1dea16330','Oficio','2023-03-15 16:45:44','2023-03-15 16:45:44',0),
('fb37feaa-efe8-40c3-b85d-80ca8ab66cf1','Altas','2023-02-23 18:49:15','2023-02-23 21:13:41',0);
/*!40000 ALTER TABLE `TipoDocumento` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-23 18:50:41
