-- MariaDB dump 10.19  Distrib 10.8.6-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: SICA
-- ------------------------------------------------------
-- Server version	10.8.6-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Cat_Edificios`
--

DROP TABLE IF EXISTS `Cat_Edificios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cat_Edificios` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `deleted` binary(1) NOT NULL DEFAULT '0',
  `UltimaActualizacion` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `FechaCreacion` datetime NOT NULL DEFAULT current_timestamp(),
  `ModificadoPor` char(36) NOT NULL,
  `CreadoPor` char(36) NOT NULL DEFAULT '',
  `Descripcion` varchar(200) NOT NULL,
  `Calle` varchar(200) NOT NULL,
  `Colonia` varchar(200) NOT NULL,
  `Municipio` varchar(200) NOT NULL,
  `Estado` varchar(200) NOT NULL,
  `CP` varchar(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `Cat_Edificios` (`Descripcion`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cat_Edificios`
--

LOCK TABLES `Cat_Edificios` WRITE;
/*!40000 ALTER TABLE `Cat_Edificios` DISABLE KEYS */;
INSERT INTO `Cat_Edificios` VALUES
('726b09f7-5c07-11ee-a933-236cb4402701','0','2023-09-25 17:57:51','2023-09-25 17:55:54','1','1','Edificio Víctor Gómez Garza','Gral. Mariano Escobedo 333','Zona Centro','Monterrey','Nuevo León','64000');
/*!40000 ALTER TABLE `Cat_Edificios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cat_Entradas_Edi`
--

DROP TABLE IF EXISTS `Cat_Entradas_Edi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cat_Entradas_Edi` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `deleted` binary(1) NOT NULL DEFAULT '0',
  `UltimaActualizacion` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `FechaCreacion` datetime NOT NULL DEFAULT current_timestamp(),
  `ModificadoPor` char(36) NOT NULL,
  `CreadoPor` char(36) NOT NULL DEFAULT '',
  `Descripcion` varchar(200) NOT NULL,
  `idEdificio` char(36) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `Cat_Entradas` (`Descripcion`) USING BTREE,
  KEY `FK1_CATENTRADA_EDIFICIO` (`idEdificio`),
  CONSTRAINT `FK1_CATENTRADA_EDIFICIO` FOREIGN KEY (`idEdificio`) REFERENCES `Cat_Edificios` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cat_Entradas_Edi`
--

LOCK TABLES `Cat_Entradas_Edi` WRITE;
/*!40000 ALTER TABLE `Cat_Entradas_Edi` DISABLE KEYS */;
INSERT INTO `Cat_Entradas_Edi` VALUES
('ea82bc35-5c07-11ee-a933-236cb4402701','0','2024-02-13 10:42:32','2023-09-25 17:59:16','1','1','Acceso Principal','726b09f7-5c07-11ee-a933-236cb4402701');
/*!40000 ALTER TABLE `Cat_Entradas_Edi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cat_Estatus`
--

DROP TABLE IF EXISTS `Cat_Estatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cat_Estatus` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `deleted` binary(1) NOT NULL DEFAULT '0',
  `UltimaActualizacion` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `FechaCreacion` datetime NOT NULL DEFAULT current_timestamp(),
  `ModificadoPor` char(36) NOT NULL,
  `CreadoPor` char(36) NOT NULL DEFAULT '',
  `Descripcion` varchar(200) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `catanio` (`Descripcion`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cat_Estatus`
--

LOCK TABLES `Cat_Estatus` WRITE;
/*!40000 ALTER TABLE `Cat_Estatus` DISABLE KEYS */;
INSERT INTO `Cat_Estatus` VALUES
('0779435b-5718-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 12:12:01','2023-09-19 12:12:01','1','1','Finalizado'),
('35f06795-5183-11ee-b06d-3cd92b4d9bf4','0','2023-09-12 09:44:08','2023-09-12 09:44:08','1','1','Generado'),
('4112a976-5183-11ee-b06d-3cd92b4d9bf4','0','2023-09-12 09:44:26','2023-09-12 09:44:26','1','1','En Visita'),
('4c103ef2-5183-11ee-b06d-3cd92b4d9bf4','0','2023-09-12 09:44:45','2023-09-12 09:44:45','1','1','Vencido');
/*!40000 ALTER TABLE `Cat_Estatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cat_Pisos`
--

DROP TABLE IF EXISTS `Cat_Pisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cat_Pisos` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `deleted` binary(1) NOT NULL DEFAULT '0',
  `UltimaActualizacion` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `FechaCreacion` datetime NOT NULL DEFAULT current_timestamp(),
  `ModificadoPor` char(36) NOT NULL,
  `CreadoPor` char(36) NOT NULL DEFAULT '',
  `Descripcion` varchar(200) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `Cat_Pisos` (`Descripcion`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cat_Pisos`
--

LOCK TABLES `Cat_Pisos` WRITE;
/*!40000 ALTER TABLE `Cat_Pisos` DISABLE KEYS */;
INSERT INTO `Cat_Pisos` VALUES
('1790a832-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:15:43','2023-09-19 11:15:12','1','1','Sotano'),
('31318c69-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:15:55','2023-09-19 11:15:55','1','1','Piso 1'),
('3a8534d9-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:16:10','2023-09-19 11:16:10','1','1','Piso 2'),
('427d055b-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:16:24','2023-09-19 11:16:24','1','1','Piso 3'),
('493b0432-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:16:35','2023-09-19 11:16:35','1','1','Piso 4'),
('4e99655d-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:16:44','2023-09-19 11:16:44','1','1','Piso 5'),
('536a403f-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:16:52','2023-09-19 11:16:52','1','1','Piso 6'),
('58822be0-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:17:01','2023-09-19 11:17:01','1','1','Piso 7'),
('5ee94704-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:17:11','2023-09-19 11:17:11','1','1','Piso 8'),
('64048868-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:17:20','2023-09-19 11:17:20','1','1','Piso 9'),
('6aec24bf-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:17:32','2023-09-19 11:17:32','1','1','Piso 10');
/*!40000 ALTER TABLE `Cat_Pisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cat_TipoAcceso`
--

DROP TABLE IF EXISTS `Cat_TipoAcceso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cat_TipoAcceso` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `deleted` binary(1) NOT NULL DEFAULT '0',
  `UltimaActualizacion` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `FechaCreacion` datetime NOT NULL DEFAULT current_timestamp(),
  `ModificadoPor` char(36) NOT NULL,
  `CreadoPor` char(36) NOT NULL DEFAULT '',
  `Descripcion` varchar(200) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `catanio` (`Descripcion`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cat_TipoAcceso`
--

LOCK TABLES `Cat_TipoAcceso` WRITE;
/*!40000 ALTER TABLE `Cat_TipoAcceso` DISABLE KEYS */;
INSERT INTO `Cat_TipoAcceso` VALUES
('f751513c-528e-11ee-b06d-3cd92b4d9bf4','0','2023-09-13 17:40:48','2023-09-13 17:40:48','1','1','Visitante'),
('fca60b42-528e-11ee-b06d-3cd92b4d9bf4','0','2023-09-13 17:40:57','2023-09-13 17:40:57','1','1','Proveedor');
/*!40000 ALTER TABLE `Cat_TipoAcceso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PreguntasFrecuentes`
--

DROP TABLE IF EXISTS `PreguntasFrecuentes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PreguntasFrecuentes` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `deleted` binary(1) NOT NULL DEFAULT '0',
  `UltimaActualizacion` datetime NOT NULL DEFAULT current_timestamp(),
  `FechaCreacion` datetime NOT NULL DEFAULT current_timestamp(),
  `ModificadoPor` char(36) NOT NULL DEFAULT '',
  `CreadoPor` char(36) NOT NULL DEFAULT '',
  `idMenu` char(36) DEFAULT NULL,
  `Pregunta` varchar(300) DEFAULT NULL,
  `Texto` varchar(700) DEFAULT NULL,
  `RutaGuia` varchar(150) DEFAULT NULL,
  `RutaVideo` varchar(150) DEFAULT NULL,
  `NombreOriginalVideo` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idMenu` (`idMenu`) USING BTREE,
  CONSTRAINT `FK_PreguntasFrecuentes_TiCentral.Menus` FOREIGN KEY (`idMenu`) REFERENCES `TiCentral`.`Menus` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PreguntasFrecuentes`
--

LOCK TABLES `PreguntasFrecuentes` WRITE;
/*!40000 ALTER TABLE `PreguntasFrecuentes` DISABLE KEYS */;
INSERT INTO `PreguntasFrecuentes` VALUES
('0a7adb5d-7a85-11ee-a933-236cb4402701','0','2023-11-03 13:10:32','2023-11-03 13:10:32','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','ed2c65d2-5984-11ee-a933-236cb4402701','Guía de Uso Reporte de Visitas',NULL,'2023-11-03 19:14:44SICA Reporte de Visitas.pdf',NULL,NULL),
('1289855c-baf2-11ee-8dee-d89d6776f970','0','2024-01-24 13:52:15','2024-01-24 13:52:15','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','7172f0d6-51b9-11ee-b06d-3cd92b4d9bf4','Guía de Uso Agenda',NULL,'2024-01-24 19:56:06SICA Agenda de Visitas.pdf',NULL,NULL),
('1984e8c4-baf0-11ee-8dee-d89d6776f970','0','2024-01-24 13:38:07','2024-01-24 13:38:07','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','964fb80d-51b9-11ee-b06d-3cd92b4d9bf4','ESCANEAR QR',NULL,'2024-01-24 19:41:59ESCANEAR QR.pdf',NULL,NULL),
('39e123cc-79b7-11ee-a933-236cb4402701','0','2023-11-02 12:37:15','2023-11-02 12:37:15','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','75500930-5ee3-11ee-a933-236cb4402701','Guía de Usuarios Edificios',NULL,'2023-11-02 18:41:24EDIFICIOS.pdf',NULL,NULL),
('53a123bf-baf1-11ee-8dee-d89d6776f970','0','2024-01-24 13:46:54','2024-01-24 13:46:54','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','INTRODUCCIÓN A LA PLATAFORMA',NULL,'2024-01-24 19:50:46INTRODUCCIÓN A LA PLATAFORMA LOGINx.pdf',NULL,NULL),
('59121c84-baf0-11ee-8dee-d89d6776f970','0','2024-01-24 13:39:54','2024-01-24 13:39:54','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','964fb80d-51b9-11ee-b06d-3cd92b4d9bf4','Guía de Uso QR',NULL,'2024-01-24 19:43:46SICA Escanear QR.pdf',NULL,NULL),
('6f697cb8-7a83-11ee-a933-236cb4402701','0','2023-11-03 12:59:02','2023-11-03 12:59:02','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','75500930-5ee3-11ee-a933-236cb4402701','Guía de Uso Edificio',NULL,'2023-11-03 19:03:14SICA Catálogo de Edificios.pdf',NULL,NULL),
('75aa63bf-79b7-11ee-a933-236cb4402701','0','2023-11-02 12:38:55','2023-11-02 12:38:55','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','ed2c65d2-5984-11ee-a933-236cb4402701','Guía de Usuario Reporte de Visitas',NULL,'2023-11-02 18:43:05REPORTE DE VISITAS.pdf',NULL,NULL),
('89b97361-bf83-11ee-8dee-d89d6776f970','0','2024-01-30 09:23:36','2024-01-30 09:23:36','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','Proceso para cargar contenido de ayuda',NULL,'2024-01-30 15:27:41MÓDULO DE AYUDA.pdf',NULL,NULL),
('ac74188e-baf0-11ee-8dee-d89d6776f970','1','2024-01-24 13:42:14','2024-01-24 13:42:14','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','4eace880-51b9-11ee-b06d-3cd92b4d9bf4','GENERACIÓN DE VISITAS',NULL,'2024-01-24 19:46:06GENERACIÓN DE VISITAS.pdf',NULL,NULL),
('d0279dc6-ca91-11ee-8dee-d89d6776f970','0','2024-02-13 11:03:30','2024-02-13 11:03:30','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','4eace880-51b9-11ee-b06d-3cd92b4d9bf4','GENERACIÓN DE VISITAS',NULL,'2024-02-13 17:04:10GENERACIÓN DE VISITAS.pdf',NULL,NULL),
('f3c1179a-baf1-11ee-8dee-d89d6776f970','0','2024-01-24 13:51:23','2024-01-24 13:51:23','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','7172f0d6-51b9-11ee-b06d-3cd92b4d9bf4','AGENDA',NULL,'2024-01-24 19:55:15AGENDA DE VISITAS.pdf',NULL,NULL);
/*!40000 ALTER TABLE `PreguntasFrecuentes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Usuario_Edificio`
--

DROP TABLE IF EXISTS `Usuario_Edificio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Usuario_Edificio` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `deleted` binary(1) NOT NULL DEFAULT '0',
  `UltimaActualizacion` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `FechaCreacion` datetime NOT NULL DEFAULT current_timestamp(),
  `ModificadoPor` char(36) NOT NULL,
  `CreadoPor` char(36) NOT NULL DEFAULT '',
  `idUsuario` char(36) DEFAULT '',
  `IdEdificio` char(36) DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK1_UE_EDIFICIO` (`IdEdificio`),
  CONSTRAINT `FK1_UE_EDIFICIO` FOREIGN KEY (`IdEdificio`) REFERENCES `Cat_Edificios` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Usuario_Edificio`
--

LOCK TABLES `Usuario_Edificio` WRITE;
/*!40000 ALTER TABLE `Usuario_Edificio` DISABLE KEYS */;
INSERT INTO `Usuario_Edificio` VALUES
('000ca481-cc1c-11ee-8dee-d89d6776f970','0','2024-02-15 10:05:12','2024-02-15 10:05:12','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','725cbf2b-cb8a-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('0a46d808-cc1c-11ee-8dee-d89d6776f970','0','2024-02-15 10:05:29','2024-02-15 10:05:29','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','9ffef3d8-78ef-11ee-a933-236cb4402701','726b09f7-5c07-11ee-a933-236cb4402701'),
('38f9e8b5-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 09:59:38','2024-02-15 09:59:38','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','a2b32920-7f1c-11ee-a933-236cb4402701','726b09f7-5c07-11ee-a933-236cb4402701'),
('3b84f859-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 09:59:42','2024-02-15 09:59:42','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','fd7e2517-cb74-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('3e457c81-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 09:59:47','2024-02-15 09:59:47','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','c2e65bf9-4cf6-11ee-8002-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('40feac50-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 09:59:52','2024-02-15 09:59:52','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','13ca7436-4cf7-11ee-8002-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('42fd7fcc-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 09:59:55','2024-02-15 09:59:55','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','673d0f77-57f1-11ee-a933-236cb4402701','726b09f7-5c07-11ee-a933-236cb4402701'),
('4503f6e7-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 09:59:58','2024-02-15 09:59:58','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','da7621fe-cb8a-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('47cb552c-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:00:03','2024-02-15 10:00:03','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','4c258716-cb8b-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('4ad01616-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:00:08','2024-02-15 10:00:08','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','c3611f3f-cb7c-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('4d2e3269-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:00:12','2024-02-15 10:00:12','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','e836d479-cb8b-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('4f4cd945-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:00:16','2024-02-15 10:00:16','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','63ce0328-cb8c-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('51b65418-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:00:20','2024-02-15 10:00:20','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','c8637a7d-cb65-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('53ad6adf-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:00:23','2024-02-15 10:00:23','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','6ae2c87e-cb7d-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('55fdb5c9-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:00:27','2024-02-15 10:00:27','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','b64be306-cb8c-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('5c10b181-5ee5-11ee-a933-236cb4402701','0','2023-09-29 09:29:28','2023-09-29 09:29:28','1','1','30adc962-7109-11ed-a880-040300000000','726b09f7-5c07-11ee-a933-236cb4402701'),
('5f42ecda-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:00:42','2024-02-15 10:00:42','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','d527e237-cb7d-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('618ee040-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:00:46','2024-02-15 10:00:46','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','25be2e30-cb8d-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('7c4f7e8c-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:01:31','2024-02-15 10:01:31','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','43f945d1-cb7e-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('7e5fddd2-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:01:35','2024-02-15 10:01:35','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','7db59a8a-cb8d-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('8082e5df-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:01:38','2024-02-15 10:01:38','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','b89d7db1-cb7e-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('825bdf56-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:01:41','2024-02-15 10:01:41','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','37e32218-cb7f-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('8489df2b-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:01:45','2024-02-15 10:01:45','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','880bad48-cb66-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('87a3dd5d-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:01:50','2024-02-15 10:01:50','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','47b92f3d-cb81-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('8c275257-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:01:58','2024-02-15 10:01:58','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','ea54175b-cb69-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('8e6c3665-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:02:02','2024-02-15 10:02:02','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','96b87c72-cb81-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('9141e134-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:02:06','2024-02-15 10:02:06','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','23411a02-cb82-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('9398f11d-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:02:10','2024-02-15 10:02:10','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','afba51f0-cb6e-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('960f32ab-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:02:14','2024-02-15 10:02:14','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','88779f4e-cb82-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('98bb31d0-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:02:19','2024-02-15 10:02:19','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','8df24c19-7444-11ee-a933-236cb4402701','726b09f7-5c07-11ee-a933-236cb4402701'),
('a5f07324-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:02:41','2024-02-15 10:02:41','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','8d70676e-cb6f-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('a7cdc753-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:02:44','2024-02-15 10:02:44','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','216481bc-cb83-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('a9ef6288-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:02:48','2024-02-15 10:02:48','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','f7e1062f-cb8d-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('ac1fbd55-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:02:51','2024-02-15 10:02:51','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','3e4faac4-cb8e-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('ae1bb1e8-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:02:55','2024-02-15 10:02:55','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','a07ef2c0-cb83-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('b0165c26-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:02:58','2024-02-15 10:02:58','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','bfdc8fec-cb8e-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('b25274bb-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:03:02','2024-02-15 10:03:02','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2d104772-cb70-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('b445d49c-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:03:05','2024-02-15 10:03:05','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','215e2a81-cb84-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('b62a7f6a-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:03:08','2024-02-15 10:03:08','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2d9c86bd-cb8f-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('b86ed99e-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:03:12','2024-02-15 10:03:12','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','8aea56c4-cb84-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('ba6c8556-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:03:15','2024-02-15 10:03:15','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','9ede1199-cb70-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('bafe4a06-5f25-11ee-a933-236cb4402701','0','2023-09-29 17:10:15','2023-09-29 17:10:15','1','1','71cc8fb8-5f24-11ee-a933-236cb4402701','726b09f7-5c07-11ee-a933-236cb4402701'),
('bc94c652-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:03:19','2024-02-15 10:03:19','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','237de01c-cb85-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('bea655a7-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:03:22','2024-02-15 10:03:22','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','caae2eb6-cb8f-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('d6615957-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:04:02','2024-02-15 10:04:02','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','73a34e8c-cb71-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('d87088ca-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:04:06','2024-02-15 10:04:06','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','57b3260a-cb90-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('da87e103-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:04:09','2024-02-15 10:04:09','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','b9c778ac-cb90-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('dc722933-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:04:12','2024-02-15 10:04:12','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','cdc6b7f5-cb71-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('dece2b41-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:04:16','2024-02-15 10:04:16','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','8639aa74-cb85-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('e1e2083f-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:04:22','2024-02-15 10:04:22','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','09988fde-cb91-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('e3fb1f0e-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:04:25','2024-02-15 10:04:25','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','47cbab04-cb72-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('e60643f9-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:04:29','2024-02-15 10:04:29','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','280971e0-0ed7-11ee-8002-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('e8533c8f-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:04:32','2024-02-15 10:04:32','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','21b4336b-cb73-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('ea3737b4-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:04:36','2024-02-15 10:04:36','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','9a34e057-cb88-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('ec0dc66b-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:04:39','2024-02-15 10:04:39','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','d79bff6f-cb73-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('ee315568-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:04:42','2024-02-15 10:04:42','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','f3e13b19-cb88-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('f059277e-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:04:46','2024-02-15 10:04:46','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','326fdc1d-cb74-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('f263ba63-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:04:49','2024-02-15 10:04:49','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','5415f34f-cb89-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('f71b3007-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:04:57','2024-02-15 10:04:57','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','bbbf4aea-cb89-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('f917ae18-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:05:01','2024-02-15 10:05:01','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','96fa7496-cb74-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701'),
('fd25e20e-cc1b-11ee-8dee-d89d6776f970','0','2024-02-15 10:05:07','2024-02-15 10:05:07','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2348cd51-cb8a-11ee-8dee-d89d6776f970','726b09f7-5c07-11ee-a933-236cb4402701');
/*!40000 ALTER TABLE `Usuario_Edificio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Visita`
--

DROP TABLE IF EXISTS `Visita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Visita` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `deleted` binary(1) NOT NULL DEFAULT '0',
  `UltimaActualizacion` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `FechaCreacion` datetime NOT NULL DEFAULT current_timestamp(),
  `ModificadoPor` char(36) NOT NULL,
  `CreadoPor` char(36) NOT NULL DEFAULT '',
  `FechaVisita` datetime NOT NULL,
  `FechaEntrada` datetime DEFAULT NULL,
  `FechaSalida` datetime DEFAULT NULL,
  `Duracion` int(11) NOT NULL DEFAULT 0,
  `IdTipoAcceso` char(36) NOT NULL,
  `Proveedor` varchar(300) DEFAULT NULL,
  `NombreVisitante` varchar(300) NOT NULL,
  `ApellidoPVisitante` varchar(300) NOT NULL,
  `ApellidoMVisitante` varchar(300) DEFAULT '',
  `idTipoentidad` char(36) DEFAULT NULL,
  `idEntidad` char(36) DEFAULT NULL,
  `NombreReceptor` varchar(300) NOT NULL,
  `ApellidoPReceptor` varchar(300) NOT NULL,
  `ApellidoMReceptor` varchar(300) DEFAULT '',
  `IdEntidadReceptor` varchar(300) NOT NULL,
  `PisoReceptor` char(36) DEFAULT NULL,
  `IdEstatus` char(36) NOT NULL DEFAULT '35f06795-5183-11ee-b06d-3cd92b4d9bf4',
  `Finalizado` int(1) DEFAULT 0,
  `EmailNotificacion` varchar(50) DEFAULT NULL,
  `IdEdificio` char(36) DEFAULT NULL,
  `IdAcceso` char(36) DEFAULT NULL,
  `Extencion` varchar(10) DEFAULT NULL,
  `Indefinido` int(11) DEFAULT 0,
  `Observaciones` varchar(800) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK1_TIPO_ACCESO` (`IdTipoAcceso`),
  KEY `FK2_ESTATUS_VISITAS` (`IdEstatus`),
  KEY `FK3_IDEDIFICIO` (`IdEdificio`),
  KEY `FK4_IDACCESO` (`IdAcceso`),
  KEY `FK5_ID_PISO` (`PisoReceptor`),
  CONSTRAINT `FK1_TIPO_ACCESO` FOREIGN KEY (`IdTipoAcceso`) REFERENCES `Cat_TipoAcceso` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK2_ESTATUS_VISITAS` FOREIGN KEY (`IdEstatus`) REFERENCES `Cat_Estatus` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK3_IDEDIFICIO` FOREIGN KEY (`IdEdificio`) REFERENCES `Cat_Edificios` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK4_IDACCESO` FOREIGN KEY (`IdAcceso`) REFERENCES `Cat_Entradas_Edi` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK5_ID_PISO` FOREIGN KEY (`PisoReceptor`) REFERENCES `Cat_Pisos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Visita`
--

LOCK TABLES `Visita` WRITE;
/*!40000 ALTER TABLE `Visita` DISABLE KEYS */;
INSERT INTO `Visita` VALUES
('40b7275f-6a78-4be2-b414-b20ce16c8654','0','2024-02-15 14:17:27','2024-02-15 14:17:27','673d0f77-57f1-11ee-a933-236cb4402701','673d0f77-57f1-11ee-a933-236cb4402701','2024-02-15 15:30:00',NULL,NULL,4,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Roberto Renato','Rodriguez','Rodriguez','a6e58850-774e-11ee-a933-236cb4402701',NULL,'Maria idalia','Arroyo','Rodriguez','86be0763-4917-11ee-8002-d89d6776f970','427d055b-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'roberto_renato@hotmail.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701','1301',1,'Lic. Roberto Renato Rodriguez Rodriguez, acude a las oficinas de la Dirección de Atencion y Seguimiento a Auditorias, de manera paulatina con un horario aproximado de ingreso 11:30 am.'),
('472711a7-5e74-4d92-8d4f-a85ac66af27e','0','2024-02-15 10:13:35','2024-02-15 10:13:35','caae2eb6-cb8f-11ee-8dee-d89d6776f970','caae2eb6-cb8f-11ee-8dee-d89d6776f970','2024-02-15 11:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Juan','Antonio','Cedillo','a6e58850-774e-11ee-a933-236cb4402701','c77d8b4a-774e-11ee-a933-236cb4402701','Raúl Sergio','González','Treviño','ebe62ae2-366b-11ee-af0d-3cd92b4d9bf4','6aec24bf-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'celene_s87@hotmail.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701','1317',0,'No contamos con el correo electronico del visitante, avisar cuando llegue');
/*!40000 ALTER TABLE `Visita` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `INS_VISITA` BEFORE INSERT ON `Visita` FOR EACH ROW BEGIN
INSERT INTO SICA.VisitaBitacora(	
	ModificadoPor,
	CreadoPor,
	IdVisita,
	IdEstatus
	)
	VALUES(
	NEW.ModificadoPor,
	NEW.CreadoPor,
	NEW.Id,
	NEW.IdEstatus
	);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `UPS_VISITA` BEFORE UPDATE ON `Visita` FOR EACH ROW BEGIN
INSERT INTO SICA.VisitaBitacora(	
	ModificadoPor,
	CreadoPor,
	IdVisita,
	IdEstatus
	)
	VALUES(
	NEW.ModificadoPor,
	NEW.CreadoPor,
	NEW.Id,
	NEW.IdEstatus
	);

	
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `VisitaBitacora`
--

DROP TABLE IF EXISTS `VisitaBitacora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VisitaBitacora` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `deleted` binary(1) NOT NULL DEFAULT '0',
  `UltimaActualizacion` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `FechaCreacion` datetime NOT NULL DEFAULT current_timestamp(),
  `ModificadoPor` char(36) NOT NULL,
  `CreadoPor` char(36) NOT NULL DEFAULT '',
  `IdVisita` char(36) NOT NULL,
  `IdEstatus` char(36) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK2_ESTATUS` (`IdEstatus`),
  CONSTRAINT `FK2_ESTATUS` FOREIGN KEY (`IdEstatus`) REFERENCES `Cat_Estatus` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VisitaBitacora`
--

LOCK TABLES `VisitaBitacora` WRITE;
/*!40000 ALTER TABLE `VisitaBitacora` DISABLE KEYS */;
INSERT INTO `VisitaBitacora` VALUES
('2bb40fbe-cc1d-11ee-8dee-d89d6776f970','0','2024-02-15 10:13:35','2024-02-15 10:13:35','caae2eb6-cb8f-11ee-8dee-d89d6776f970','caae2eb6-cb8f-11ee-8dee-d89d6776f970','472711a7-5e74-4d92-8d4f-a85ac66af27e','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('3cfe25a1-cc3f-11ee-8dee-d89d6776f970','0','2024-02-15 14:17:27','2024-02-15 14:17:27','673d0f77-57f1-11ee-a933-236cb4402701','673d0f77-57f1-11ee-a933-236cb4402701','40b7275f-6a78-4be2-b414-b20ce16c8654','35f06795-5183-11ee-b06d-3cd92b4d9bf4');
/*!40000 ALTER TABLE `VisitaBitacora` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-15 18:54:06
