-- MariaDB dump 10.19  Distrib 10.8.6-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: SICA
-- ------------------------------------------------------
-- Server version	10.8.6-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Cat_Edificios`
--

DROP TABLE IF EXISTS `Cat_Edificios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cat_Edificios` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `deleted` binary(1) NOT NULL DEFAULT '0',
  `UltimaActualizacion` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `FechaCreacion` datetime NOT NULL DEFAULT current_timestamp(),
  `ModificadoPor` char(36) NOT NULL,
  `CreadoPor` char(36) NOT NULL DEFAULT '',
  `Descripcion` varchar(200) NOT NULL,
  `Calle` varchar(200) NOT NULL,
  `Colonia` varchar(200) NOT NULL,
  `Municipio` varchar(200) NOT NULL,
  `Estado` varchar(200) NOT NULL,
  `CP` varchar(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `Cat_Edificios` (`Descripcion`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cat_Edificios`
--

LOCK TABLES `Cat_Edificios` WRITE;
/*!40000 ALTER TABLE `Cat_Edificios` DISABLE KEYS */;
INSERT INTO `Cat_Edificios` VALUES
('726b09f7-5c07-11ee-a933-236cb4402701','0','2023-09-25 17:57:51','2023-09-25 17:55:54','1','1','Edificio Víctor Gómez Garza','Gral. Mariano Escobedo 333','Zona Centro','Monterrey','Nuevo León','64000');
/*!40000 ALTER TABLE `Cat_Edificios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cat_Entradas_Edi`
--

DROP TABLE IF EXISTS `Cat_Entradas_Edi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cat_Entradas_Edi` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `deleted` binary(1) NOT NULL DEFAULT '0',
  `UltimaActualizacion` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `FechaCreacion` datetime NOT NULL DEFAULT current_timestamp(),
  `ModificadoPor` char(36) NOT NULL,
  `CreadoPor` char(36) NOT NULL DEFAULT '',
  `Descripcion` varchar(200) NOT NULL,
  `idEdificio` char(36) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `Cat_Entradas` (`Descripcion`) USING BTREE,
  KEY `FK1_CATENTRADA_EDIFICIO` (`idEdificio`),
  CONSTRAINT `FK1_CATENTRADA_EDIFICIO` FOREIGN KEY (`idEdificio`) REFERENCES `Cat_Edificios` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cat_Entradas_Edi`
--

LOCK TABLES `Cat_Entradas_Edi` WRITE;
/*!40000 ALTER TABLE `Cat_Entradas_Edi` DISABLE KEYS */;
INSERT INTO `Cat_Entradas_Edi` VALUES
('13ce6f30-5e61-11ee-a933-236cb4402701','0','2023-09-28 17:42:33','2023-09-28 17:42:33','1','1','Acceso C','726b09f7-5c07-11ee-a933-236cb4402701'),
('ea82bc35-5c07-11ee-a933-236cb4402701','0','2023-09-28 17:42:12','2023-09-25 17:59:16','1','1','Acceso A','726b09f7-5c07-11ee-a933-236cb4402701'),
('f46bd706-5c07-11ee-a933-236cb4402701','0','2023-09-28 17:42:19','2023-09-25 17:59:33','1','1','Acceso B','726b09f7-5c07-11ee-a933-236cb4402701');
/*!40000 ALTER TABLE `Cat_Entradas_Edi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cat_Estatus`
--

DROP TABLE IF EXISTS `Cat_Estatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cat_Estatus` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `deleted` binary(1) NOT NULL DEFAULT '0',
  `UltimaActualizacion` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `FechaCreacion` datetime NOT NULL DEFAULT current_timestamp(),
  `ModificadoPor` char(36) NOT NULL,
  `CreadoPor` char(36) NOT NULL DEFAULT '',
  `Descripcion` varchar(200) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `catanio` (`Descripcion`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cat_Estatus`
--

LOCK TABLES `Cat_Estatus` WRITE;
/*!40000 ALTER TABLE `Cat_Estatus` DISABLE KEYS */;
INSERT INTO `Cat_Estatus` VALUES
('0779435b-5718-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 12:12:01','2023-09-19 12:12:01','1','1','Finalizado'),
('35f06795-5183-11ee-b06d-3cd92b4d9bf4','0','2023-09-12 09:44:08','2023-09-12 09:44:08','1','1','Generado'),
('4112a976-5183-11ee-b06d-3cd92b4d9bf4','0','2023-09-12 09:44:26','2023-09-12 09:44:26','1','1','En Visita'),
('4c103ef2-5183-11ee-b06d-3cd92b4d9bf4','0','2023-09-12 09:44:45','2023-09-12 09:44:45','1','1','Vencido');
/*!40000 ALTER TABLE `Cat_Estatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cat_Pisos`
--

DROP TABLE IF EXISTS `Cat_Pisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cat_Pisos` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `deleted` binary(1) NOT NULL DEFAULT '0',
  `UltimaActualizacion` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `FechaCreacion` datetime NOT NULL DEFAULT current_timestamp(),
  `ModificadoPor` char(36) NOT NULL,
  `CreadoPor` char(36) NOT NULL DEFAULT '',
  `Descripcion` varchar(200) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `Cat_Pisos` (`Descripcion`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cat_Pisos`
--

LOCK TABLES `Cat_Pisos` WRITE;
/*!40000 ALTER TABLE `Cat_Pisos` DISABLE KEYS */;
INSERT INTO `Cat_Pisos` VALUES
('1790a832-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:15:43','2023-09-19 11:15:12','1','1','Sotano'),
('31318c69-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:15:55','2023-09-19 11:15:55','1','1','Piso 1'),
('3a8534d9-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:16:10','2023-09-19 11:16:10','1','1','Piso 2'),
('427d055b-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:16:24','2023-09-19 11:16:24','1','1','Piso 3'),
('493b0432-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:16:35','2023-09-19 11:16:35','1','1','Piso 4'),
('4e99655d-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:16:44','2023-09-19 11:16:44','1','1','Piso 5'),
('536a403f-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:16:52','2023-09-19 11:16:52','1','1','Piso 6'),
('58822be0-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:17:01','2023-09-19 11:17:01','1','1','Piso 7'),
('5ee94704-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:17:11','2023-09-19 11:17:11','1','1','Piso 8'),
('64048868-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:17:20','2023-09-19 11:17:20','1','1','Piso 9'),
('6aec24bf-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:17:32','2023-09-19 11:17:32','1','1','Piso 10');
/*!40000 ALTER TABLE `Cat_Pisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cat_TipoAcceso`
--

DROP TABLE IF EXISTS `Cat_TipoAcceso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cat_TipoAcceso` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `deleted` binary(1) NOT NULL DEFAULT '0',
  `UltimaActualizacion` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `FechaCreacion` datetime NOT NULL DEFAULT current_timestamp(),
  `ModificadoPor` char(36) NOT NULL,
  `CreadoPor` char(36) NOT NULL DEFAULT '',
  `Descripcion` varchar(200) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `catanio` (`Descripcion`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cat_TipoAcceso`
--

LOCK TABLES `Cat_TipoAcceso` WRITE;
/*!40000 ALTER TABLE `Cat_TipoAcceso` DISABLE KEYS */;
INSERT INTO `Cat_TipoAcceso` VALUES
('f751513c-528e-11ee-b06d-3cd92b4d9bf4','0','2023-09-13 17:40:48','2023-09-13 17:40:48','1','1','Visitante'),
('fca60b42-528e-11ee-b06d-3cd92b4d9bf4','0','2023-09-13 17:40:57','2023-09-13 17:40:57','1','1','Proveedor');
/*!40000 ALTER TABLE `Cat_TipoAcceso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PreguntasFrecuentes`
--

DROP TABLE IF EXISTS `PreguntasFrecuentes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PreguntasFrecuentes` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `deleted` binary(1) NOT NULL DEFAULT '0',
  `UltimaActualizacion` datetime NOT NULL DEFAULT current_timestamp(),
  `FechaCreacion` datetime NOT NULL DEFAULT current_timestamp(),
  `ModificadoPor` char(36) NOT NULL DEFAULT '',
  `CreadoPor` char(36) NOT NULL DEFAULT '',
  `idMenu` char(36) DEFAULT NULL,
  `Pregunta` varchar(300) DEFAULT NULL,
  `Texto` varchar(700) DEFAULT NULL,
  `RutaGuia` varchar(150) DEFAULT NULL,
  `RutaVideo` varchar(150) DEFAULT NULL,
  `NombreOriginalVideo` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idMenu` (`idMenu`) USING BTREE,
  CONSTRAINT `FK_PreguntasFrecuentes_TiCentral.Menus` FOREIGN KEY (`idMenu`) REFERENCES `TiCentral`.`Menus` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PreguntasFrecuentes`
--

LOCK TABLES `PreguntasFrecuentes` WRITE;
/*!40000 ALTER TABLE `PreguntasFrecuentes` DISABLE KEYS */;
/*!40000 ALTER TABLE `PreguntasFrecuentes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Usuario_Edificio`
--

DROP TABLE IF EXISTS `Usuario_Edificio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Usuario_Edificio` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `deleted` binary(1) NOT NULL DEFAULT '0',
  `UltimaActualizacion` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `FechaCreacion` datetime NOT NULL DEFAULT current_timestamp(),
  `ModificadoPor` char(36) NOT NULL,
  `CreadoPor` char(36) NOT NULL DEFAULT '',
  `idUsuario` char(36) DEFAULT '',
  `IdEdificio` char(36) DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK1_UE_EDIFICIO` (`IdEdificio`),
  CONSTRAINT `FK1_UE_EDIFICIO` FOREIGN KEY (`IdEdificio`) REFERENCES `Cat_Edificios` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Usuario_Edificio`
--

LOCK TABLES `Usuario_Edificio` WRITE;
/*!40000 ALTER TABLE `Usuario_Edificio` DISABLE KEYS */;
INSERT INTO `Usuario_Edificio` VALUES
('5c10b181-5ee5-11ee-a933-236cb4402701','0','2023-09-29 09:29:28','2023-09-29 09:29:28','1','1','30adc962-7109-11ed-a880-040300000000','726b09f7-5c07-11ee-a933-236cb4402701'),
('bafe4a06-5f25-11ee-a933-236cb4402701','0','2023-09-29 17:10:15','2023-09-29 17:10:15','1','1','71cc8fb8-5f24-11ee-a933-236cb4402701','726b09f7-5c07-11ee-a933-236cb4402701');
/*!40000 ALTER TABLE `Usuario_Edificio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Visita`
--

DROP TABLE IF EXISTS `Visita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Visita` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `deleted` binary(1) NOT NULL DEFAULT '0',
  `UltimaActualizacion` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `FechaCreacion` datetime NOT NULL DEFAULT current_timestamp(),
  `ModificadoPor` char(36) NOT NULL,
  `CreadoPor` char(36) NOT NULL DEFAULT '',
  `FechaVisita` datetime NOT NULL,
  `FechaEntrada` datetime DEFAULT NULL,
  `FechaSalida` datetime DEFAULT NULL,
  `Duracion` int(11) NOT NULL DEFAULT 0,
  `IdTipoAcceso` char(36) NOT NULL,
  `Proveedor` varchar(300) DEFAULT NULL,
  `NombreVisitante` varchar(300) DEFAULT NULL,
  `ApellidoPVisitante` varchar(300) DEFAULT NULL,
  `ApellidoMVisitante` varchar(300) DEFAULT NULL,
  `idTipoentidad` char(36) DEFAULT NULL,
  `idEntidad` char(36) DEFAULT NULL,
  `NombreReceptor` varchar(300) NOT NULL,
  `ApellidoPReceptor` varchar(300) NOT NULL,
  `ApellidoMReceptor` varchar(300) NOT NULL,
  `IdEntidadReceptor` varchar(300) NOT NULL,
  `PisoReceptor` char(36) DEFAULT NULL,
  `IdEstatus` char(36) NOT NULL DEFAULT '35f06795-5183-11ee-b06d-3cd92b4d9bf4',
  `Finalizado` int(1) DEFAULT 0,
  `EmailNotificacion` varchar(50) DEFAULT NULL,
  `IdEdificio` char(36) DEFAULT NULL,
  `IdAcceso` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK1_TIPO_ACCESO` (`IdTipoAcceso`),
  KEY `FK2_ESTATUS_VISITAS` (`IdEstatus`),
  KEY `FK3_IDEDIFICIO` (`IdEdificio`),
  KEY `FK4_IDACCESO` (`IdAcceso`),
  KEY `FK5_ID_PISO` (`PisoReceptor`),
  CONSTRAINT `FK1_TIPO_ACCESO` FOREIGN KEY (`IdTipoAcceso`) REFERENCES `Cat_TipoAcceso` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK2_ESTATUS_VISITAS` FOREIGN KEY (`IdEstatus`) REFERENCES `Cat_Estatus` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK3_IDEDIFICIO` FOREIGN KEY (`IdEdificio`) REFERENCES `Cat_Edificios` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK4_IDACCESO` FOREIGN KEY (`IdAcceso`) REFERENCES `Cat_Entradas_Edi` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK5_ID_PISO` FOREIGN KEY (`PisoReceptor`) REFERENCES `Cat_Pisos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Visita`
--

LOCK TABLES `Visita` WRITE;
/*!40000 ALTER TABLE `Visita` DISABLE KEYS */;
INSERT INTO `Visita` VALUES
('0d0057a2-ab86-46be-bde4-1ffc0e134d85','0','2023-10-16 17:11:38','2023-10-16 17:11:38','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('0df928d8-2957-4904-a8d3-762a1632c908','0','2023-10-16 17:45:32','2023-10-16 17:45:32','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('104312ce-4c6d-4a32-a174-49cc813b3340','0','2023-10-16 17:32:10','2023-10-16 17:32:10','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('11b3eed3-8100-4cf7-8609-c3146577e053','0','2023-10-16 17:28:06','2023-10-16 17:28:06','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('13832acb-aed3-4934-bfef-f5158ae268e5','0','2023-10-16 10:54:12','2023-10-16 10:54:12','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('16ade83c-b94b-49fc-96bb-96746f6a4447','0','2023-10-16 11:10:53','2023-10-16 11:10:53','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('1fe736be-1488-4d3b-8088-f51f8c767a59','0','2023-10-16 11:02:13','2023-10-16 11:02:13','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('3171b54a-7c5e-4bd6-8bdc-83d6890de2a5','0','2023-10-16 16:58:04','2023-10-16 16:58:04','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('47af42f4-24c1-4cc8-9c66-1efb63ecda19','0','2023-10-16 16:43:57','2023-10-16 16:43:57','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('4eaacecf-2683-47ce-a134-903dfc3d22fe','0','2023-10-16 16:04:24','2023-10-16 16:00:24','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-17 16:00:00','2023-10-16 22:07:06','2023-10-16 22:07:57',1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','5ee94704-5710-11ee-b06d-3cd92b4d9bf4','0779435b-5718-11ee-b06d-3cd92b4d9bf4',1,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('5269a0aa-0448-4677-9558-a12520238fb3','0','2023-10-16 11:05:08','2023-10-16 11:05:08','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('581ad8d6-c99e-4088-9ebd-f4224e216e35','0','2023-10-16 17:19:02','2023-10-16 17:19:02','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('66d74aa8-3426-47b7-9568-81bc614bca90','0','2023-10-16 10:57:00','2023-10-16 10:57:00','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('77ad92ba-954c-44f1-92b0-1a71d8cc22e3','0','2023-10-16 17:20:49','2023-10-16 17:20:49','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('7e007d3a-29f4-45b3-9f0d-3eaee569302b','0','2023-10-16 10:55:44','2023-10-16 10:55:44','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('7eea0a07-f9ba-44d5-942a-c401996c9ef7','0','2023-10-16 10:51:37','2023-10-16 10:51:37','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('93d9a532-da8e-489b-bbe3-d286d43e625d','0','2023-10-16 11:06:58','2023-10-16 11:06:58','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('a0906686-7a30-4ebc-a999-583575dd76e4','0','2023-10-16 17:27:22','2023-10-16 17:27:22','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('a0db985f-1055-4e75-bf4a-9f2b0a25f2e4','0','2023-10-16 17:52:34','2023-10-16 17:52:34','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('a76559c6-1519-4bb7-85ff-8a26819131d6','0','2023-10-16 10:59:13','2023-10-16 10:59:13','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('a9e869dd-11f4-4c49-8da7-990e43ef0b7b','0','2023-10-16 16:50:56','2023-10-16 16:50:56','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('addf3b03-fc51-4d5a-b2df-aa53afc65993','0','2023-10-16 10:01:38','2023-10-16 10:01:38','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','31318c69-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('afb84354-e0fa-4667-b3f6-7a0cc4866666','0','2023-10-16 16:42:34','2023-10-16 16:42:34','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('b99e82b8-aea3-40f1-be34-1378ca68cfaa','0','2023-10-16 11:00:18','2023-10-16 11:00:18','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('c0ad7c26-239e-4cdf-b93a-3aaba1d5dfc7','0','2023-10-16 10:59:25','2023-10-16 10:59:25','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('c102974f-a82f-42f9-8f6a-58774b0c2321','0','2023-10-16 11:07:26','2023-10-16 11:07:26','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('c812d1fd-0b5e-444e-9154-e76b275980b9','0','2023-10-16 11:07:12','2023-10-16 11:07:12','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('cb8183cd-adbe-4ed8-9884-9cb7fbfb1593','0','2023-10-16 11:09:32','2023-10-16 11:09:32','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('d2c83b6c-6c77-49a4-b651-43a82fe62a37','0','2023-10-16 17:37:36','2023-10-16 17:37:36','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('e265fac6-e818-4723-86e0-bc4ffcd75356','0','2023-10-16 17:19:37','2023-10-16 17:19:37','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('e3155433-e909-4159-ad69-04a439e504ee','0','2023-10-16 17:48:58','2023-10-16 17:48:58','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('e4846f8c-e88c-4e69-b37f-bb4de042942b','0','2023-10-16 17:00:11','2023-10-16 17:00:11','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('e61c711d-94f4-49e7-af09-f27b4c46bb6b','0','2023-10-16 17:24:29','2023-10-16 17:24:29','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('e9c691a2-2ead-4831-b2f6-2fbff927225a','0','2023-10-16 16:40:41','2023-10-16 16:40:41','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('eed0893a-3181-4612-ba4d-61e278ce8d70','0','2023-10-16 16:38:29','2023-10-16 16:38:29','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('f7754118-403a-4017-9d8d-5bb7b0468de6','0','2023-10-16 15:02:30','2023-10-16 13:12:48','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-17 16:00:00','2023-10-16 21:06:03',NULL,2,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','3c3e7a00-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','5ee94704-5710-11ee-b06d-3cd92b4d9bf4','4112a976-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('fba2124e-1e11-44f3-bc64-4199a749f493','0','2023-10-16 17:06:47','2023-10-16 17:06:47','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701'),
('ff89b9e3-4992-4614-aa6e-b838163f590f','0','2023-10-16 17:27:26','2023-10-16 17:27:26','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','2023-10-16 16:00:00',NULL,NULL,1,'f751513c-528e-11ee-b06d-3cd92b4d9bf4',NULL,'Adolfo Angel','garcia','martinez','23baa1d6-4361-11ee-9014-3cd92b4d9bf4','05ad88a0-4e69-11ee-b06d-3cd92b4d9bf4','veronica','cardenaz','medina','0d6c5ee9-366c-11ee-af0d-3cd92b4d9bf4','536a403f-5710-11ee-b06d-3cd92b4d9bf4','35f06795-5183-11ee-b06d-3cd92b4d9bf4',0,'aagarcia@cecapmex.com','726b09f7-5c07-11ee-a933-236cb4402701','ea82bc35-5c07-11ee-a933-236cb4402701');
/*!40000 ALTER TABLE `Visita` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `INS_VISITA` BEFORE INSERT ON `Visita` FOR EACH ROW BEGIN
INSERT INTO SICA.VisitaBitacora(	
	ModificadoPor,
	CreadoPor,
	IdVisita,
	IdEstatus
	)
	VALUES(
	NEW.ModificadoPor,
	NEW.CreadoPor,
	NEW.Id,
	NEW.IdEstatus
	);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `UPS_VISITA` BEFORE UPDATE ON `Visita` FOR EACH ROW BEGIN
INSERT INTO SICA.VisitaBitacora(	
	ModificadoPor,
	CreadoPor,
	IdVisita,
	IdEstatus
	)
	VALUES(
	NEW.ModificadoPor,
	NEW.CreadoPor,
	NEW.Id,
	NEW.IdEstatus
	);

	
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `VisitaBitacora`
--

DROP TABLE IF EXISTS `VisitaBitacora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VisitaBitacora` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `deleted` binary(1) NOT NULL DEFAULT '0',
  `UltimaActualizacion` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `FechaCreacion` datetime NOT NULL DEFAULT current_timestamp(),
  `ModificadoPor` char(36) NOT NULL,
  `CreadoPor` char(36) NOT NULL DEFAULT '',
  `IdVisita` char(36) NOT NULL,
  `IdEstatus` char(36) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK2_ESTATUS` (`IdEstatus`),
  CONSTRAINT `FK2_ESTATUS` FOREIGN KEY (`IdEstatus`) REFERENCES `Cat_Estatus` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VisitaBitacora`
--

LOCK TABLES `VisitaBitacora` WRITE;
/*!40000 ALTER TABLE `VisitaBitacora` DISABLE KEYS */;
INSERT INTO `VisitaBitacora` VALUES
('03e17f7b-6c4d-11ee-a933-236cb4402701','0','2023-10-16 10:54:12','2023-10-16 10:54:12','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','13832acb-aed3-4934-bfef-f5158ae268e5','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('0662ee6a-6c83-11ee-a933-236cb4402701','0','2023-10-16 17:20:49','2023-10-16 17:20:49','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','77ad92ba-954c-44f1-92b0-1a71d8cc22e3','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('0a89281c-6c84-11ee-a933-236cb4402701','0','2023-10-16 17:28:06','2023-10-16 17:28:06','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','11b3eed3-8100-4cf7-8609-c3146577e053','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('1063d9c3-6c81-11ee-a933-236cb4402701','0','2023-10-16 17:06:47','2023-10-16 17:06:47','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','fba2124e-1e11-44f3-bc64-4199a749f493','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('1c2f4ddc-6c7d-11ee-a933-236cb4402701','0','2023-10-16 16:38:29','2023-10-16 16:38:29','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','eed0893a-3181-4612-ba4d-61e278ce8d70','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('2220de04-6c4e-11ee-a933-236cb4402701','0','2023-10-16 11:02:13','2023-10-16 11:02:13','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','1fe736be-1488-4d3b-8088-f51f8c767a59','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('240af8fb-6c80-11ee-a933-236cb4402701','0','2023-10-16 17:00:11','2023-10-16 17:00:11','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','e4846f8c-e88c-4e69-b37f-bb4de042942b','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('27feea4d-6c4f-11ee-a933-236cb4402701','0','2023-10-16 11:09:32','2023-10-16 11:09:32','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','cb8183cd-adbe-4ed8-9884-9cb7fbfb1593','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('3abc7012-6c4d-11ee-a933-236cb4402701','0','2023-10-16 10:55:44','2023-10-16 10:55:44','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','7e007d3a-29f4-45b3-9f0d-3eaee569302b','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('3af02816-6c78-11ee-a933-236cb4402701','0','2023-10-16 16:03:33','2023-10-16 16:03:33','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','4eaacecf-2683-47ce-a134-903dfc3d22fe','4112a976-5183-11ee-b06d-3cd92b4d9bf4'),
('58784630-6c4f-11ee-a933-236cb4402701','0','2023-10-16 11:10:53','2023-10-16 11:10:53','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','16ade83c-b94b-49fc-96bb-96746f6a4447','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('596bd4e7-6c78-11ee-a933-236cb4402701','0','2023-10-16 16:04:24','2023-10-16 16:04:24','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','4eaacecf-2683-47ce-a134-903dfc3d22fe','0779435b-5718-11ee-b06d-3cd92b4d9bf4'),
('597b4324-6c78-11ee-a933-236cb4402701','0','2023-10-16 16:04:24','2023-10-16 16:04:24','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','4eaacecf-2683-47ce-a134-903dfc3d22fe','0779435b-5718-11ee-b06d-3cd92b4d9bf4'),
('5e60d603-6c85-11ee-a933-236cb4402701','0','2023-10-16 17:37:36','2023-10-16 17:37:36','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','d2c83b6c-6c77-49a4-b651-43a82fe62a37','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('605f653c-6c60-11ee-a933-236cb4402701','0','2023-10-16 13:12:48','2023-10-16 13:12:48','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','f7754118-403a-4017-9d8d-5bb7b0468de6','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('67ab1813-6c4d-11ee-a933-236cb4402701','0','2023-10-16 10:57:00','2023-10-16 10:57:00','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','66d74aa8-3426-47b7-9568-81bc614bca90','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('6abef55c-6c7d-11ee-a933-236cb4402701','0','2023-10-16 16:40:41','2023-10-16 16:40:41','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','e9c691a2-2ead-4831-b2f6-2fbff927225a','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('75608688-6c87-11ee-a933-236cb4402701','0','2023-10-16 17:52:34','2023-10-16 17:52:34','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','a0db985f-1055-4e75-bf4a-9f2b0a25f2e4','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('7a445b1b-6c86-11ee-a933-236cb4402701','0','2023-10-16 17:45:32','2023-10-16 17:45:32','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','0df928d8-2957-4904-a8d3-762a1632c908','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('895865f9-6c83-11ee-a933-236cb4402701','0','2023-10-16 17:24:29','2023-10-16 17:24:29','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','e61c711d-94f4-49e7-af09-f27b4c46bb6b','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('8ab3717f-6c4e-11ee-a933-236cb4402701','0','2023-10-16 11:05:08','2023-10-16 11:05:08','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','5269a0aa-0448-4677-9558-a12520238fb3','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('9c597ecd-6c84-11ee-a933-236cb4402701','0','2023-10-16 17:32:10','2023-10-16 17:32:10','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','104312ce-4c6d-4a32-a174-49cc813b3340','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('a747239e-6c4c-11ee-a933-236cb4402701','0','2023-10-16 10:51:37','2023-10-16 10:51:37','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','7eea0a07-f9ba-44d5-942a-c401996c9ef7','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('aba44f97-6c45-11ee-a933-236cb4402701','0','2023-10-16 10:01:38','2023-10-16 10:01:38','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','addf3b03-fc51-4d5a-b2df-aa53afc65993','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('ae69b04d-6c7d-11ee-a933-236cb4402701','0','2023-10-16 16:42:34','2023-10-16 16:42:34','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','afb84354-e0fa-4667-b3f6-7a0cc4866666','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('b3744709-6c6f-11ee-a933-236cb4402701','0','2023-10-16 15:02:30','2023-10-16 15:02:30','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','f7754118-403a-4017-9d8d-5bb7b0468de6','4112a976-5183-11ee-b06d-3cd92b4d9bf4'),
('b74e738f-6c4d-11ee-a933-236cb4402701','0','2023-10-16 10:59:13','2023-10-16 10:59:13','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','a76559c6-1519-4bb7-85ff-8a26819131d6','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('bdb3cf85-6c81-11ee-a933-236cb4402701','0','2023-10-16 17:11:38','2023-10-16 17:11:38','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','0d0057a2-ab86-46be-bde4-1ffc0e134d85','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('be5615dd-6c4d-11ee-a933-236cb4402701','0','2023-10-16 10:59:25','2023-10-16 10:59:25','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','c0ad7c26-239e-4cdf-b93a-3aaba1d5dfc7','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('c6a957c8-6c82-11ee-a933-236cb4402701','0','2023-10-16 17:19:02','2023-10-16 17:19:02','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','581ad8d6-c99e-4088-9ebd-f4224e216e35','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('ca3b1091-6c77-11ee-a933-236cb4402701','0','2023-10-16 16:00:24','2023-10-16 16:00:24','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','4eaacecf-2683-47ce-a134-903dfc3d22fe','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('cc62ce9a-6c4e-11ee-a933-236cb4402701','0','2023-10-16 11:06:58','2023-10-16 11:06:58','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','93d9a532-da8e-489b-bbe3-d286d43e625d','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('d4adb857-6c4e-11ee-a933-236cb4402701','0','2023-10-16 11:07:12','2023-10-16 11:07:12','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','c812d1fd-0b5e-444e-9154-e76b275980b9','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('d8c2b206-6c7f-11ee-a933-236cb4402701','0','2023-10-16 16:58:04','2023-10-16 16:58:04','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','3171b54a-7c5e-4bd6-8bdc-83d6890de2a5','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('d99948c2-6c7e-11ee-a933-236cb4402701','0','2023-10-16 16:50:56','2023-10-16 16:50:56','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','a9e869dd-11f4-4c49-8da7-990e43ef0b7b','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('db33a98b-6c82-11ee-a933-236cb4402701','0','2023-10-16 17:19:37','2023-10-16 17:19:37','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','e265fac6-e818-4723-86e0-bc4ffcd75356','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('dd03858a-6c4e-11ee-a933-236cb4402701','0','2023-10-16 11:07:26','2023-10-16 11:07:26','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','c102974f-a82f-42f9-8f6a-58774b0c2321','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('de171651-6c4d-11ee-a933-236cb4402701','0','2023-10-16 11:00:18','2023-10-16 11:00:18','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','b99e82b8-aea3-40f1-be34-1378ca68cfaa','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('dfbd646c-6c7d-11ee-a933-236cb4402701','0','2023-10-16 16:43:57','2023-10-16 16:43:57','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','47af42f4-24c1-4cc8-9c66-1efb63ecda19','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('f023f142-6c83-11ee-a933-236cb4402701','0','2023-10-16 17:27:22','2023-10-16 17:27:22','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','a0906686-7a30-4ebc-a999-583575dd76e4','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('f2d29961-6c83-11ee-a933-236cb4402701','0','2023-10-16 17:27:26','2023-10-16 17:27:26','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','ff89b9e3-4992-4614-aa6e-b838163f590f','35f06795-5183-11ee-b06d-3cd92b4d9bf4'),
('f4e5b0a7-6c86-11ee-a933-236cb4402701','0','2023-10-16 17:48:58','2023-10-16 17:48:58','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','e3155433-e909-4159-ad69-04a439e504ee','35f06795-5183-11ee-b06d-3cd92b4d9bf4');
/*!40000 ALTER TABLE `VisitaBitacora` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-16 18:56:37
