-- MariaDB dump 10.19  Distrib 10.8.6-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: SICA
-- ------------------------------------------------------
-- Server version	10.8.6-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Cat_Edificios`
--

DROP TABLE IF EXISTS `Cat_Edificios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cat_Edificios` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `deleted` binary(1) NOT NULL DEFAULT '0',
  `UltimaActualizacion` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `FechaCreacion` datetime NOT NULL DEFAULT current_timestamp(),
  `ModificadoPor` char(36) NOT NULL,
  `CreadoPor` char(36) NOT NULL DEFAULT '',
  `Descripcion` varchar(200) NOT NULL,
  `Calle` varchar(200) NOT NULL,
  `Colonia` varchar(200) NOT NULL,
  `Municipio` varchar(200) NOT NULL,
  `Estado` varchar(200) NOT NULL,
  `CP` varchar(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `Cat_Edificios` (`Descripcion`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cat_Edificios`
--

LOCK TABLES `Cat_Edificios` WRITE;
/*!40000 ALTER TABLE `Cat_Edificios` DISABLE KEYS */;
INSERT INTO `Cat_Edificios` VALUES
('726b09f7-5c07-11ee-a933-236cb4402701','0','2023-09-25 17:57:51','2023-09-25 17:55:54','1','1','Edificio Víctor Gómez Garza','Gral. Mariano Escobedo 333','Zona Centro','Monterrey','Nuevo León','64000');
/*!40000 ALTER TABLE `Cat_Edificios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cat_Entradas_Edi`
--

DROP TABLE IF EXISTS `Cat_Entradas_Edi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cat_Entradas_Edi` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `deleted` binary(1) NOT NULL DEFAULT '0',
  `UltimaActualizacion` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `FechaCreacion` datetime NOT NULL DEFAULT current_timestamp(),
  `ModificadoPor` char(36) NOT NULL,
  `CreadoPor` char(36) NOT NULL DEFAULT '',
  `Descripcion` varchar(200) NOT NULL,
  `idEdificio` char(36) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `Cat_Entradas` (`Descripcion`) USING BTREE,
  KEY `FK1_CATENTRADA_EDIFICIO` (`idEdificio`),
  CONSTRAINT `FK1_CATENTRADA_EDIFICIO` FOREIGN KEY (`idEdificio`) REFERENCES `Cat_Edificios` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cat_Entradas_Edi`
--

LOCK TABLES `Cat_Entradas_Edi` WRITE;
/*!40000 ALTER TABLE `Cat_Entradas_Edi` DISABLE KEYS */;
INSERT INTO `Cat_Entradas_Edi` VALUES
('13ce6f30-5e61-11ee-a933-236cb4402701','0','2023-09-28 17:42:33','2023-09-28 17:42:33','1','1','Acceso C','726b09f7-5c07-11ee-a933-236cb4402701'),
('ea82bc35-5c07-11ee-a933-236cb4402701','0','2023-09-28 17:42:12','2023-09-25 17:59:16','1','1','Acceso A','726b09f7-5c07-11ee-a933-236cb4402701'),
('f46bd706-5c07-11ee-a933-236cb4402701','0','2023-09-28 17:42:19','2023-09-25 17:59:33','1','1','Acceso B','726b09f7-5c07-11ee-a933-236cb4402701');
/*!40000 ALTER TABLE `Cat_Entradas_Edi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cat_Estatus`
--

DROP TABLE IF EXISTS `Cat_Estatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cat_Estatus` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `deleted` binary(1) NOT NULL DEFAULT '0',
  `UltimaActualizacion` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `FechaCreacion` datetime NOT NULL DEFAULT current_timestamp(),
  `ModificadoPor` char(36) NOT NULL,
  `CreadoPor` char(36) NOT NULL DEFAULT '',
  `Descripcion` varchar(200) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `catanio` (`Descripcion`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cat_Estatus`
--

LOCK TABLES `Cat_Estatus` WRITE;
/*!40000 ALTER TABLE `Cat_Estatus` DISABLE KEYS */;
INSERT INTO `Cat_Estatus` VALUES
('0779435b-5718-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 12:12:01','2023-09-19 12:12:01','1','1','Finalizado'),
('35f06795-5183-11ee-b06d-3cd92b4d9bf4','0','2023-09-12 09:44:08','2023-09-12 09:44:08','1','1','Generado'),
('4112a976-5183-11ee-b06d-3cd92b4d9bf4','0','2023-09-12 09:44:26','2023-09-12 09:44:26','1','1','En Visita'),
('4c103ef2-5183-11ee-b06d-3cd92b4d9bf4','0','2023-09-12 09:44:45','2023-09-12 09:44:45','1','1','Vencido');
/*!40000 ALTER TABLE `Cat_Estatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cat_Pisos`
--

DROP TABLE IF EXISTS `Cat_Pisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cat_Pisos` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `deleted` binary(1) NOT NULL DEFAULT '0',
  `UltimaActualizacion` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `FechaCreacion` datetime NOT NULL DEFAULT current_timestamp(),
  `ModificadoPor` char(36) NOT NULL,
  `CreadoPor` char(36) NOT NULL DEFAULT '',
  `Descripcion` varchar(200) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `Cat_Pisos` (`Descripcion`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cat_Pisos`
--

LOCK TABLES `Cat_Pisos` WRITE;
/*!40000 ALTER TABLE `Cat_Pisos` DISABLE KEYS */;
INSERT INTO `Cat_Pisos` VALUES
('1790a832-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:15:43','2023-09-19 11:15:12','1','1','Sotano'),
('31318c69-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:15:55','2023-09-19 11:15:55','1','1','Piso 1'),
('3a8534d9-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:16:10','2023-09-19 11:16:10','1','1','Piso 2'),
('427d055b-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:16:24','2023-09-19 11:16:24','1','1','Piso 3'),
('493b0432-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:16:35','2023-09-19 11:16:35','1','1','Piso 4'),
('4e99655d-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:16:44','2023-09-19 11:16:44','1','1','Piso 5'),
('536a403f-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:16:52','2023-09-19 11:16:52','1','1','Piso 6'),
('58822be0-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:17:01','2023-09-19 11:17:01','1','1','Piso 7'),
('5ee94704-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:17:11','2023-09-19 11:17:11','1','1','Piso 8'),
('64048868-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:17:20','2023-09-19 11:17:20','1','1','Piso 9'),
('6aec24bf-5710-11ee-b06d-3cd92b4d9bf4','0','2023-09-19 11:17:32','2023-09-19 11:17:32','1','1','Piso 10');
/*!40000 ALTER TABLE `Cat_Pisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cat_TipoAcceso`
--

DROP TABLE IF EXISTS `Cat_TipoAcceso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cat_TipoAcceso` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `deleted` binary(1) NOT NULL DEFAULT '0',
  `UltimaActualizacion` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `FechaCreacion` datetime NOT NULL DEFAULT current_timestamp(),
  `ModificadoPor` char(36) NOT NULL,
  `CreadoPor` char(36) NOT NULL DEFAULT '',
  `Descripcion` varchar(200) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `catanio` (`Descripcion`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cat_TipoAcceso`
--

LOCK TABLES `Cat_TipoAcceso` WRITE;
/*!40000 ALTER TABLE `Cat_TipoAcceso` DISABLE KEYS */;
INSERT INTO `Cat_TipoAcceso` VALUES
('f751513c-528e-11ee-b06d-3cd92b4d9bf4','0','2023-09-13 17:40:48','2023-09-13 17:40:48','1','1','Visitante'),
('fca60b42-528e-11ee-b06d-3cd92b4d9bf4','0','2023-09-13 17:40:57','2023-09-13 17:40:57','1','1','Proveedor');
/*!40000 ALTER TABLE `Cat_TipoAcceso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PreguntasFrecuentes`
--

DROP TABLE IF EXISTS `PreguntasFrecuentes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PreguntasFrecuentes` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `deleted` binary(1) NOT NULL DEFAULT '0',
  `UltimaActualizacion` datetime NOT NULL DEFAULT current_timestamp(),
  `FechaCreacion` datetime NOT NULL DEFAULT current_timestamp(),
  `ModificadoPor` char(36) NOT NULL DEFAULT '',
  `CreadoPor` char(36) NOT NULL DEFAULT '',
  `idMenu` char(36) DEFAULT NULL,
  `Pregunta` varchar(300) DEFAULT NULL,
  `Texto` varchar(700) DEFAULT NULL,
  `RutaGuia` varchar(150) DEFAULT NULL,
  `RutaVideo` varchar(150) DEFAULT NULL,
  `NombreOriginalVideo` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idMenu` (`idMenu`) USING BTREE,
  CONSTRAINT `FK_PreguntasFrecuentes_TiCentral.Menus` FOREIGN KEY (`idMenu`) REFERENCES `TiCentral`.`Menus` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PreguntasFrecuentes`
--

LOCK TABLES `PreguntasFrecuentes` WRITE;
/*!40000 ALTER TABLE `PreguntasFrecuentes` DISABLE KEYS */;
INSERT INTO `PreguntasFrecuentes` VALUES
('0a7adb5d-7a85-11ee-a933-236cb4402701','0','2023-11-03 13:10:32','2023-11-03 13:10:32','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','ed2c65d2-5984-11ee-a933-236cb4402701','Guía de Uso Reporte de Visitas',NULL,'2023-11-03 19:14:44SICA Reporte de Visitas.pdf',NULL,NULL),
('268ae64d-79b7-11ee-a933-236cb4402701','0','2023-11-02 12:36:42','2023-11-02 12:36:42','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','7172f0d6-51b9-11ee-b06d-3cd92b4d9bf4','Guía de Usuarios Agenda',NULL,'2023-11-02 18:40:52AGENDA DE VISITAS.pdf',NULL,NULL),
('39e123cc-79b7-11ee-a933-236cb4402701','0','2023-11-02 12:37:15','2023-11-02 12:37:15','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','75500930-5ee3-11ee-a933-236cb4402701','Guía de Usuarios Edificios',NULL,'2023-11-02 18:41:24EDIFICIOS.pdf',NULL,NULL),
('483eb29d-7a82-11ee-a933-236cb4402701','0','2023-11-03 12:50:47','2023-11-03 12:50:47','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','4eace880-51b9-11ee-b06d-3cd92b4d9bf4','Guía de Usuario Generar Visita',NULL,'2023-11-03 18:54:59GENERACIÓN DE VISITAS.pdf',NULL,NULL),
('553e39ab-79b7-11ee-a933-236cb4402701','0','2023-11-02 12:38:01','2023-11-02 12:38:01','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','964fb80d-51b9-11ee-b06d-3cd92b4d9bf4','Guía de Usuario Escanear QR',NULL,'2023-11-02 18:42:10ESCANEAR QR.pdf',NULL,NULL),
('62b70eb6-7a82-11ee-a933-236cb4402701','0','2023-11-03 12:51:31','2023-11-03 12:51:31','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','4eace880-51b9-11ee-b06d-3cd92b4d9bf4','Guía de Uso Generar Visita',NULL,'2023-11-03 18:55:43SICA Generar Visitas.pdf',NULL,NULL),
('6f697cb8-7a83-11ee-a933-236cb4402701','0','2023-11-03 12:59:02','2023-11-03 12:59:02','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','75500930-5ee3-11ee-a933-236cb4402701','Guía de Uso Edificio',NULL,'2023-11-03 19:03:14SICA Catálogo de Edificios.pdf',NULL,NULL),
('75aa63bf-79b7-11ee-a933-236cb4402701','0','2023-11-02 12:38:55','2023-11-02 12:38:55','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','ed2c65d2-5984-11ee-a933-236cb4402701','Guía de Usuario Reporte de Visitas',NULL,'2023-11-02 18:43:05REPORTE DE VISITAS.pdf',NULL,NULL),
('c43bcec1-7a84-11ee-a933-236cb4402701','0','2023-11-03 13:08:34','2023-11-03 13:08:34','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','7172f0d6-51b9-11ee-b06d-3cd92b4d9bf4','Guía de Uso Agenda de Visitas',NULL,'2023-11-03 19:12:46SICA Agenda de Visitas.pdf',NULL,NULL),
('e049e567-7a84-11ee-a933-236cb4402701','0','2023-11-03 13:09:21','2023-11-03 13:09:21','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','964fb80d-51b9-11ee-b06d-3cd92b4d9bf4','Guía de Uso Escanear QR',NULL,'2023-11-03 19:13:33SICA Escanear QR.pdf',NULL,NULL);
/*!40000 ALTER TABLE `PreguntasFrecuentes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Usuario_Edificio`
--

DROP TABLE IF EXISTS `Usuario_Edificio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Usuario_Edificio` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `deleted` binary(1) NOT NULL DEFAULT '0',
  `UltimaActualizacion` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `FechaCreacion` datetime NOT NULL DEFAULT current_timestamp(),
  `ModificadoPor` char(36) NOT NULL,
  `CreadoPor` char(36) NOT NULL DEFAULT '',
  `idUsuario` char(36) DEFAULT '',
  `IdEdificio` char(36) DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK1_UE_EDIFICIO` (`IdEdificio`),
  CONSTRAINT `FK1_UE_EDIFICIO` FOREIGN KEY (`IdEdificio`) REFERENCES `Cat_Edificios` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Usuario_Edificio`
--

LOCK TABLES `Usuario_Edificio` WRITE;
/*!40000 ALTER TABLE `Usuario_Edificio` DISABLE KEYS */;
INSERT INTO `Usuario_Edificio` VALUES
('5c10b181-5ee5-11ee-a933-236cb4402701','0','2023-09-29 09:29:28','2023-09-29 09:29:28','1','1','30adc962-7109-11ed-a880-040300000000','726b09f7-5c07-11ee-a933-236cb4402701'),
('6d20b187-7449-11ee-a933-236cb4402701','0','2023-10-26 14:48:40','2023-10-26 14:48:40','30adc962-7109-11ed-a880-040300000000','30adc962-7109-11ed-a880-040300000000','8df24c19-7444-11ee-a933-236cb4402701','726b09f7-5c07-11ee-a933-236cb4402701'),
('bafe4a06-5f25-11ee-a933-236cb4402701','0','2023-09-29 17:10:15','2023-09-29 17:10:15','1','1','71cc8fb8-5f24-11ee-a933-236cb4402701','726b09f7-5c07-11ee-a933-236cb4402701');
/*!40000 ALTER TABLE `Usuario_Edificio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Visita`
--

DROP TABLE IF EXISTS `Visita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Visita` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `deleted` binary(1) NOT NULL DEFAULT '0',
  `UltimaActualizacion` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `FechaCreacion` datetime NOT NULL DEFAULT current_timestamp(),
  `ModificadoPor` char(36) NOT NULL,
  `CreadoPor` char(36) NOT NULL DEFAULT '',
  `FechaVisita` datetime NOT NULL,
  `FechaEntrada` datetime DEFAULT NULL,
  `FechaSalida` datetime DEFAULT NULL,
  `Duracion` int(11) NOT NULL DEFAULT 0,
  `IdTipoAcceso` char(36) NOT NULL,
  `Proveedor` varchar(300) DEFAULT NULL,
  `NombreVisitante` varchar(300) DEFAULT NULL,
  `ApellidoPVisitante` varchar(300) DEFAULT NULL,
  `ApellidoMVisitante` varchar(300) DEFAULT NULL,
  `idTipoentidad` char(36) DEFAULT NULL,
  `idEntidad` char(36) DEFAULT NULL,
  `NombreReceptor` varchar(300) NOT NULL,
  `ApellidoPReceptor` varchar(300) NOT NULL,
  `ApellidoMReceptor` varchar(300) NOT NULL,
  `IdEntidadReceptor` varchar(300) NOT NULL,
  `PisoReceptor` char(36) DEFAULT NULL,
  `IdEstatus` char(36) NOT NULL DEFAULT '35f06795-5183-11ee-b06d-3cd92b4d9bf4',
  `Finalizado` int(1) DEFAULT 0,
  `EmailNotificacion` varchar(50) DEFAULT NULL,
  `IdEdificio` char(36) DEFAULT NULL,
  `IdAcceso` char(36) DEFAULT NULL,
  `Extencion` varchar(10) DEFAULT NULL,
  `Indefinido` int(11) DEFAULT 0,
  `Observaciones` varchar(800) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK1_TIPO_ACCESO` (`IdTipoAcceso`),
  KEY `FK2_ESTATUS_VISITAS` (`IdEstatus`),
  KEY `FK3_IDEDIFICIO` (`IdEdificio`),
  KEY `FK4_IDACCESO` (`IdAcceso`),
  KEY `FK5_ID_PISO` (`PisoReceptor`),
  CONSTRAINT `FK1_TIPO_ACCESO` FOREIGN KEY (`IdTipoAcceso`) REFERENCES `Cat_TipoAcceso` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK2_ESTATUS_VISITAS` FOREIGN KEY (`IdEstatus`) REFERENCES `Cat_Estatus` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK3_IDEDIFICIO` FOREIGN KEY (`IdEdificio`) REFERENCES `Cat_Edificios` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK4_IDACCESO` FOREIGN KEY (`IdAcceso`) REFERENCES `Cat_Entradas_Edi` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK5_ID_PISO` FOREIGN KEY (`PisoReceptor`) REFERENCES `Cat_Pisos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Visita`
--

LOCK TABLES `Visita` WRITE;
/*!40000 ALTER TABLE `Visita` DISABLE KEYS */;
/*!40000 ALTER TABLE `Visita` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `INS_VISITA` BEFORE INSERT ON `Visita` FOR EACH ROW BEGIN
INSERT INTO SICA.VisitaBitacora(	
	ModificadoPor,
	CreadoPor,
	IdVisita,
	IdEstatus
	)
	VALUES(
	NEW.ModificadoPor,
	NEW.CreadoPor,
	NEW.Id,
	NEW.IdEstatus
	);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `UPS_VISITA` BEFORE UPDATE ON `Visita` FOR EACH ROW BEGIN
INSERT INTO SICA.VisitaBitacora(	
	ModificadoPor,
	CreadoPor,
	IdVisita,
	IdEstatus
	)
	VALUES(
	NEW.ModificadoPor,
	NEW.CreadoPor,
	NEW.Id,
	NEW.IdEstatus
	);

	
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `VisitaBitacora`
--

DROP TABLE IF EXISTS `VisitaBitacora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VisitaBitacora` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `deleted` binary(1) NOT NULL DEFAULT '0',
  `UltimaActualizacion` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `FechaCreacion` datetime NOT NULL DEFAULT current_timestamp(),
  `ModificadoPor` char(36) NOT NULL,
  `CreadoPor` char(36) NOT NULL DEFAULT '',
  `IdVisita` char(36) NOT NULL,
  `IdEstatus` char(36) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK2_ESTATUS` (`IdEstatus`),
  CONSTRAINT `FK2_ESTATUS` FOREIGN KEY (`IdEstatus`) REFERENCES `Cat_Estatus` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VisitaBitacora`
--

LOCK TABLES `VisitaBitacora` WRITE;
/*!40000 ALTER TABLE `VisitaBitacora` DISABLE KEYS */;
/*!40000 ALTER TABLE `VisitaBitacora` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-18 17:51:20
